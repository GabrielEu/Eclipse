package exerc�cios;

import java.util.Random;

import javax.swing.*;

public class exercicio11 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[][] matriz = new String[3][3];
 		String text = "";
 		int[] compararJogada = new int[6], repetirJogada = new int [5];
		int contar = 0, jogada, jogadas = 0, jogadaPc;
		Random gerarJogada = new Random();
 		
		//Atribuir valores a matriz
		for(int linha = 0; linha < 3; linha++) {
			
			for(int coluna = 0; coluna < 3; coluna++) {
				contar++;
				
				matriz[linha][coluna] = ""+contar;
				
				//Criar desenho
				if(contar == 9) {
					
					text += "    "+matriz[0][0]+"       |       ";
					text += "  "+matriz[0][1]+"       |       "; 
					text += "  "+matriz[0][2]+"\n-------------------------------------\n";
						
					text += "    "+matriz[1][0]+"       |       ";
					text += "  "+matriz[1][1]+"       |       ";
					text += "  "+matriz[1][2]+"\n-------------------------------------\n";
						
					text += "    "+matriz[2][0]+"       |       ";
					text += "  "+matriz[2][1]+"       |       ";
					text += "  "+matriz[2][2]+"";
				}
			}
		}
		
		contar = 0;
		JOptionPane.showMessageDialog(null, "1� jogador --> X\n2� jogador --> O", "", 1);
		
		do {
			jogada = Integer.parseInt(JOptionPane.showInputDialog(null, text+"\n\nDigite onde gostaria de jogar\n\n", "*****  1� JOGADOR  *****", 1));
			
			//Contar jogadas
			jogadas++;
			compararJogada[contar] += jogada;
			text = "";
			contar++;
			
			//Posibilidades
			if(jogada == 1) {
				matriz[0][0] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			} else if(jogada == 2){
				matriz[0][1] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogada == 3){
				matriz[0][2] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogada == 4){
				matriz[1][0] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogada == 5){
				matriz[1][1] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogada == 6){
				matriz[1][2] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogada == 7){
				matriz[2][0] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogada == 8){
				matriz[2][1] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogada == 9){
				matriz[2][2] = "X";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			}
			
			//Jogada do pc
			jogadaPc = gerarJogada.nextInt(9);
			
			//Validar a repeti��o de jogadas do computador
			for(int i = 0; i < 5; i++) {
				
				if(repetirJogada[i] != 0) {
					repetirJogada[i] = jogadaPc;
				}
			}
			
			for(int i = 0; i < 5; i++) {
				
				if((jogadaPc == compararJogada[i]) || (jogadaPc == repetirJogada[i])) {
					
					while((jogadaPc == compararJogada[i]) || (jogadaPc == repetirJogada[i])) {
						
						jogadaPc = gerarJogada.nextInt(9);
						
					}
				}
			}
			
			//Contar jogadas
			jogadas++;
			text = "";
			
			System.out.println(jogadaPc);
			
			if(jogadaPc == 1) {
				matriz[0][0] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			} else if(jogadaPc == 2){
				matriz[0][1] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogadaPc == 3){
				matriz[0][2] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogadaPc == 4){
				matriz[1][0] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogadaPc == 5){
				matriz[1][1] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
				
			}else if(jogadaPc == 6){
				matriz[1][2] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogadaPc == 7){
				matriz[2][0] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogadaPc == 8){
				matriz[2][1] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			
			}else if(jogadaPc == 9){
				matriz[2][2] = "O";
				text += "    "+matriz[0][0]+"       |       ";
				text += "  "+matriz[0][1]+"       |       "; 
				text += "  "+matriz[0][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[1][0]+"       |       ";
				text += "  "+matriz[1][1]+"       |       ";
				text += "  "+matriz[1][2]+"\n-------------------------------------\n";
				
				text += "    "+matriz[2][0]+"       |       ";
				text += "  "+matriz[2][1]+"       |       ";
				text += "  "+matriz[2][2]+"";
			} else {
				
			}
			
			
		}while(jogadas != 9);
	
	}		
}
	

