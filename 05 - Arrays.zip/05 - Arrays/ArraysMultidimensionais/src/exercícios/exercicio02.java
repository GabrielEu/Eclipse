package exerc�cios;

import javax.swing.*;

public class exercicio02 {

	public static void main(String[] args) {
		
		//Variavel
		String teste;
		int soma4 = 0, soma2 = 0;
		int contar = 0;
		int somaDiagP = 0, somaDiagS = 0;
		int somaAll = 0;
		
		//Atribuir n�meros
		int[][] n = new int[5][5];
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 5; i2++) {
				
				contar++;
				n[i][i2] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o "+contar+"� n�mero"));
			}
		}
	
		//Soma 4� linha
		for(int i = 0; i < 5; i++) {
			soma4 += n[3][i];
		}
		
		//Exibir soma 4� linha
		JOptionPane.showMessageDialog(null, "A soma da 4� linha � "+soma4, "*****  SOMA  *****", 1);
	
		//Soma 2� linha
		for(int i = 0; i < 5; i++) {
			
			soma2 += n[1][i];
		}
		
		//Exibir soma 2� linha
		JOptionPane.showMessageDialog(null, "A soma da 2� linha � de "+soma2, "*****  SOMA  ******", 1);
	
		//Soma diagonal principal
		for(int i = 0; i < 5; i++) {
			somaDiagP += n[i][i];
		}
		
		//Exibir soma diagonal principal
		JOptionPane.showMessageDialog(null, "A soma da diagonal secund�ria � de "+somaDiagP, "*****  SOMA  *****", 1);
		
		//Soma diagonal principal
		for(int i = 4; i >= 0; i--) {
			somaDiagS += n[i][i];
		}
		
		//Exibir soma diagonal secund�ria
		JOptionPane.showMessageDialog(null, "A soma da diagonal secund�ria � de "+somaDiagS, "*****  SOMA  *****", 1);
		
		//Soma todos os elementos
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 5;i2++) {
				
				somaAll += n[i][i2];
				
			}
		}
		
		//Exibir soma de todos os elementos
		JOptionPane.showMessageDialog(null, "A soma de todos os elementos � "+somaAll, "*****  SOMA  *****", 1);
		
		//Escrever todos os elementos
		String text = "";
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 5; i2++) {
				
				text += n[i][i2]+"                ";
				
				if(i2 == 4) {
					text += "\n";
				}
				
			}
		}
		
		//Exibir todos os elementos
		JOptionPane.showMessageDialog(null, text, "******  OS ELEMENTOS DIGITADOS  ******", 1);
		
		
		
	}
}
