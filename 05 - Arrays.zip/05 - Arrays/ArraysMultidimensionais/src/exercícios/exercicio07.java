package exerc�cios;

import java.util.function.ToLongBiFunction;

import javax.swing.*;

public class exercicio07 {

	public static void main(String[]args) {
		
		//Vari�veis
		String[] produto = new String[20];
		int[] cadastro = new int[20], qtdProduto = new int[20];
		double[] preco = new double[20], total = new double[20];
		double totalCompra;
		int compra, quantidade;
		String text = "", carrinho = "";
		
		//Atribuir cadastros
		for(int i = 0; i < 19; i++) {
			
			cadastro[i+1] = i+1;
		}
		
		//Registrar produtos
		produto[0] = "Arroz 5 KG"; produto[1] = "Arroz 1 KG"; produto[2] = "Feij�o 5 KG"; produto[3] = "Feij�o 1 KG"; produto[4] = "Macarr�o 500 GR"; produto[5] = "Farinha de trigo 2 KG";
		produto[6] = "Ketchup 370 GR"; produto[7] = "Maionese 480 GR"; produto[8] = "Gelatina 50 GR"; produto[9] = "Macarr�o Instant�neo 120 GR"; 
		produto[10] = "Creme de Leite 150 GR"; produto[11] = "Leite Condensado 150 GR"; produto[12] = "Leite 1 L"; produto[13] = "Chocolate em P� 500 GR";
		produto[14] = "Pepino em Conserva 600 GR"; produto[15] = "Vinagre 550 ML"; produto[16] = "Sal 500 GR"; produto[17] = "A��car 550 GR";
		produto[18] = "Fermento 150 FR"; produto[19] = "Biscoito de Chocolate 70 GR";
		
		//Registrar valroes
		preco[0] = 9.50; preco[1] = 9.50; preco[2] = 9.50; preco[3] = 9.50; preco[4] = 9.50; preco[5] = 9.50; preco[6] = 9.50; preco[7] = 9.50; preco[8] = 9.50;
		preco[9] = 9.50; preco[10] = 9.50; preco[11] = 9.50; preco[12] = 9.50; preco[13] = 9.50; preco[14] = 9.50; preco[15] = 9.50; preco[16] = 9.50; preco[17] = 9.50;
		preco[18] = 9.50; preco[19] = 9.50;
		
		//Criar tabela
		for(int i = 0; i < 19; i++) {
			text += cadastro[i+1]+"     |     "+produto[i]+"     |    R$"+preco[i]+"\n";
		}
		
		compra = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o c�digo do produto que deseja comprar ou 0 para finalizar\n\n"+text, "", 1));
		
	  do {
		quantidade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade do produto", "", 1));
		
		for(int i = 0; i < 19; i++) {
			
			if(compra == cadastro[i+1]) {
				
				total[i] = quantidade * preco[i];
				totalCompra = total[0]+total[1]+total[2]+total[3]+total[4]+total[5]+total[6]+total[7]+total[8]+total[9]+total[10]+total[11]+total[12]+total[13]+
						total[14]+total[15]+total[16]+total[17]+total[18]+total[19];
				qtdProduto[i] = quantidade;
				carrinho += cadastro[i+1]+"     |     "+produto[i]+"     |     R$"+preco[i]+"     |     Quantidade: "+qtdProduto[i]+"     |     Total: R$"+total[i]+"\n";
				carrinho += "O total da sua compra � de: R$"+totalCompra+"\n";
			}
			
		}
		
		compra = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o c�digo do produto que deseja comprar ou 0 para finalizar\n"+text, "", 1));
		}while(compra != 0);
	
	  JOptionPane.showMessageDialog(null, carrinho, "", 1);
	  
	  
	}	
}
