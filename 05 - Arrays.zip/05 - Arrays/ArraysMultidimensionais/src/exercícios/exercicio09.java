package exerc�cios;

import javax.swing.*;

public class exercicio09 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[][] filme = new String[3][50];  //0 = nome  ~~  1 = genero  ~~  2 = valor
		String[][] usuario = new String[5][50];  //0 = nome  ~~  1 = idade  ~~  2 = endere�o  ~~  3 = telefone  ~~  4 = email
		String[][] locado = new String[50][3]; //0 = nome  ~~  1 = nome do filme  ~~  2 = dias
		Object[] escolha = {"Cadastrar filme", "Cadastrar usu�rio", "Locar filme", "Excluir filme", "Excluir usu�rio", "Filmes locados", "Sair"};
		int continuar = 0;
		boolean valida = true, permissao = false;
		String procurar;
		
		Object menu = JOptionPane.showInputDialog(null, "Informe o que deseja fazer", "", JOptionPane.PLAIN_MESSAGE, null, escolha, "");
		
	  do {
	  
		if(menu.equals("Cadastrar filme")) {
			
			for(int i = 0; continuar == 0; i++) {
				
				filme[0][i] = JOptionPane.showInputDialog(null, "Informe o nome do filme", "", 1);
				filme[1][i] = JOptionPane.showInputDialog(null, "Informe o g�nero do filme", "", 1);
				filme[2][i] = JOptionPane.showInputDialog(null, "Informe o valor do filme", "", 1);
			
				continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar registrando?", "", 1);
			}

		} else if(menu.equals("Cadastrar usu�rio")){
			
			continuar = 0;
			
			for(int i = 0; continuar == 0; i++) {
				usuario[0][i] = JOptionPane.showInputDialog(null, "Informe o nome do usu�rio", "", 1);
				usuario[1][i] = ""+JOptionPane.showInputDialog(null, "Informe a idade do usu�rio", "", 1);
				usuario[2][i] = ""+JOptionPane.showInputDialog(null, "Informe o endere�o do usu�rio", "", 1);
				usuario[3][i] = ""+JOptionPane.showInputDialog(null, "Informe o telefone do usu�rio", "", 1);
				usuario[4][i] = ""+JOptionPane.showInputDialog(null, "Informe o email do usu�rio", "", 1);
				
				continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar registrando?", "", 1);
				
			}
			
		} else if(menu.equals("Locar filme")) {
			
			continuar = 0;
			
				procurar = JOptionPane.showInputDialog(null, "Informe o nome do filme", "", 1);
				
				for(int i = 0; i < 50; i++) {
					
				if(procurar.equals(locado[i][1])) {
					valida = true;
					
					locado[i][1] = procurar;
					
					procurar = JOptionPane.showInputDialog(null, "Informe o nome do usu�rio", "", 1);
					
					for(int i2 = 0; i2 < 50; i2++) {
						
						if(!procurar.equals(usuario[0][i])) {
						
							usuario[0][i] = procurar;

							locado[i][2] = ""+JOptionPane.showInputDialog(null,"Informe os dias", "", 1);
						} else if (procurar.equals(usuario[0][i])){
							valida = false;
						} else {
							
						}
					}
				} else if (procurar.equals(locado[i][1])){
					valida = false;
				} else {
					
				}
			}
			
			if(valida == false) {
				JOptionPane.showMessageDialog(null, "Filme ou usu�rio n�o encontrado", "", 1);
			}
			
			
		} else if(menu.equals("Excluir usu�rio")) {
			valida = true;
		
			procurar = JOptionPane.showInputDialog(null, "Informe o nome do usu�rio que deseja excluir", "", 1);
			
			for(int i = 0; i < 50; i++) {
				
				if(procurar.equals(usuario[0][i])) {
					
					valida = true;
					
					for(int i2 = 0; i2 < 50; i2++) {
						
						if(procurar.equals(usuario[0][i2])) {
							permissao = false;
							valida = false;
						}else if(!procurar.equals(locado[i2][1])){
							permissao = true;
							valida = true;
						} else {
							
						}
						
					}
				
					
				} else if(!procurar.equals(usuario[0][i])){
					valida = false;
				} else {
					
				}
			}
			
			if(valida == false){
				JOptionPane.showMessageDialog(null, "Usu�rio n�o encontrado", "", 1);
			}
			
			
		} else if(menu.equals("Excluir filme")) {
			valida = true;
		
			procurar = JOptionPane.showInputDialog(null, "Informe o nome do filme que deseja excluir", "", 1);
			
			for(int i = 0; i < 50; i++) {
				
				if(procurar.equals(filme[0][i])) {
					
					valida = true;
					
					for(int i2 = 0; i2 < 50; i2++) {
						
						if(procurar.equals(locado[i2][1])) {
							JOptionPane.showMessageDialog(null, "O filme est� locado", "", 1);
							permissao = false;
						}else if(!procurar.equals(locado[i2][1])){
							permissao = true;
						} else {
							
						}
						
					}
					
				} else if(!procurar.equals(filme[0][i])){
					valida = false;
				} else {
					
				}
				
			}
			
			if(valida == false){
				JOptionPane.showMessageDialog(null, "Filme n�o encontrado", "", 1);
			}
			
		}
		
		
		
		
		menu = JOptionPane.showInputDialog(null, "Informe o que deseja fazer", "", JOptionPane.PLAIN_MESSAGE, null, escolha, "");
		
	  }while(!menu.equals("Sair"));
	  
	  
	}
	
}
