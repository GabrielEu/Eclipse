package exerc�cios;

import javax.swing.*;

public class exercicio05 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[][] info = new String[20][6];
 		int perguntaSair = 0, masc = 0, fem = 0, registrados = 0, pctgMasc, pctgFem;
 		String text = "";
 		Double peso, altura, imc;
		int muitoAbaixo = 0, abaixo = 0, normal = 0, acima = 0, obeso = 0, obeso1 = 0, obeso2 = 0, obeso3 = 0;
 		
 		
		for(int i = 0; perguntaSair == 0; i++) {
		
			for(int i2 = 0; perguntaSair == 0; i2++) {
				
				info[i2][0] = JOptionPane.showInputDialog(null, "Informe seu nome", "", 3);
				info[i2][1] = JOptionPane.showInputDialog(null, "Informe seu sexo", "", 3);
					if(info[i2][1].equals("Masculino")) {
						masc++;
					}
				
				altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe seu altura", "", 3));
					info[i2][2] = altura+"";
				peso = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe seu peso", "", 3));
					info[i2][3] = peso+"";
				imc =  (altura * altura) / peso;
				info[i2][4] = imc+"";
			
				if((imc < 17) && (imc < 18.49)) {
					info[i2][5] = "Muito abaixo do peso";
					muitoAbaixo++;
				} else if((imc >= 18.5) && (imc <= 24.99)){
					info[i2][5] = "Abaixo do peso";
					abaixo++;
				}else if((imc >= 25) && (imc <= 29.99)) {
					info[i2][5] = "Peso normal";
					normal++;
				} else if((imc >= 30) && (imc <= 34.99)) {
					info[i2][5] = "Acima do peso";
					acima++;
				} else if((imc >= 35) && (imc <= 39.99)) {
					info[i2][5] = "Obesidade I";
					obeso++;
				} else if((imc >= 35) && (imc <= 39.99)) {
					info[i2][5] = "Obesidade II (Severa)";
					obeso2++;
				} else{
					info[i2][5] = "Obesidade III (M�rbida)";
					obeso3++;
				}
			
				//Contar registrados
				registrados++;
				
				text += "Nome do "+(i+1)+"� registrado: "+info[i2][0]+"\n";
				text += "Situa��o do "+(i+1)+"� registrado: "+info[i2][5]+"\n\n";
				
				perguntaSair = JOptionPane.showConfirmDialog(null, "Deseja cadastrar novamente?", "", 1);
				
			}
			
		if(i > 5) {
			i = 0;
		}
		
		}
		
		pctgMasc = (masc * 100) / registrados;
		pctgFem = (fem * 100) / registrados;
		
		text += "Porcentagem de homens: "+pctgMasc+"%\n";
		text += "Quantidade de homens: "+masc+"\n\n";
		text += "Porcentagem de mulheres: "+pctgFem+"%\n";
		text += "Quantidade de mulheres: "+fem+"\n\n";
		
		text += "Quantidade de pessoas muito abaixo do peso: "+muitoAbaixo+"\n";
		text += "Quantidade de pessoas abaixo do peso: "+abaixo+"\n";
		text += "Quantidade de pessoas no peso normal: "+normal+"\n";
		text += "Quantidade de pessoas acima do peso: "+acima+"\n";
		text += "Quantidade de pessoas em obesidade I: "+obeso+"\n";
		text += "Quantidade de pessoas em obesidade II: "+obeso2+"\n";
		text += "Quantidade de pessoas em obesidade III: "+obeso3+"\n";
		
		JOptionPane.showMessageDialog(null, text,"", 1);
		
	}
}
