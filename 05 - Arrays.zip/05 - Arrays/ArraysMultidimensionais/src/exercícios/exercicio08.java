package exerc�cios;

import javax.swing.*;

public class exercicio08 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[][] alunos = new String[50][50];
			/*0 = nome
			  1 = sexo
			  2 = media
			  3 = situa��o*/		 
		String cadastrar = "";
		String escolha, situacao, excluir;
		int pctgHomens, pctgMulheres, masc = 0, fem = 0;
		int aprov = 0, reprov = 0, exam = 0, pctgAprov, pctgExam, pctgReprov;
		double notas = 0, calcMedia;
		boolean valida = false;
		
		
	
		do {
			
		escolha = JOptionPane.showInputDialog(null, "Digite o que deseja fazer\n ~ CADAS para cadastrar\n ~ EXC para excluir\n ~ ES para estat�sticas\n ~ SAIR para sair do sistema", "", 1);
		
		switch(escolha) {
		
		
			
		
		case"cadas":
			
			int i = 0;
			while(!cadastrar.equals("sair")){
				i++;
				notas = 0;
				
				cadastrar = JOptionPane.showInputDialog(null, "Informe o nome do "+i+"� aluno ou SAIR para sair", "*****  CADASTRAR  *****", 1);
				
					for(int indice = 0; indice < 50; indice++) {  		//N�o sai do la�o de cadastrar // n�o corresponde ao comando SAIR
						
						if(cadastrar.equals(alunos[0][i])) {
							JOptionPane.showMessageDialog(null, "J� existe algu�m cadastrado com esse nome, tente novamente", "*****  ERROR  *****", 0);
							
							valida = false;
							
							do {
								cadastrar = JOptionPane.showInputDialog(null, "Informe o nome do "+i+"� aluno ou SAIR para sair", "*****  CADASTRAR  *****", 1);
								
								if(!cadastrar.equals(alunos[0][i])) {
									JOptionPane.showMessageDialog(null, "J� existe algu�m cadastrado com esse nome, tente novamente", "*****  ERROR  *****", 0);
								} else {
									alunos[0][i] = cadastrar;
								}
							}while(valida == false);
						}
					}
					
				alunos[0][i] = cadastrar;
				
				cadastrar = JOptionPane.showInputDialog(null, "Informe o sexo do "+i+"� aluno ou SAIR para sair", "*****  CADASTRAR  *****", 1);
				
					if(cadastrar.equals("masculino")) {
						masc++;
					} else if(cadastrar.equals("feminino")){
						fem++;
					} else {
						
					}
					
				alunos[1][i] = cadastrar;
				
				notas += Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a 1� nota do "+i+" aluno", "", 1));
				notas += Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a 2� nota do "+i+" aluno", "", 1));
				notas += Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a 3� nota do "+i+" aluno", "", 1));
				
				calcMedia = notas / 3;
			
				if((calcMedia >= 7) && (calcMedia <= 10)) {
					situacao = "Aprovado";
					aprov++;
				} else if((calcMedia >= 3) && (calcMedia <= 6.9)) {
					situacao = "Em exame";
					exam++;
				} else {
					situacao = "Reprovado";
					reprov++;
				}
				
				alunos[2][i] = String.valueOf(calcMedia);
				alunos[3][i] = situacao;
				
			}
			
			
		case"exc":
			
			excluir = JOptionPane.showInputDialog(null, "Informe o nome do aluno na qual deseja excluir", "", 3);
			
			for(int i2 = 0; i2 < 50; i2++) {
				
				if(excluir.equals(alunos[0][i2])) {
					alunos[0][i2] = null;
				} else {
					valida = false;
				}
			}
			
			if(valida == false) {
				JOptionPane.showMessageDialog(null, "O nome n�o foi registrado", "*****  ERROR  *****", 0);
			}
			
		case"es":
			int totalSexo = masc + fem;
			pctgHomens = (masc * 100) / totalSexo;
			pctgMulheres = (fem * 100) / totalSexo;
			
			int totalSituacao = aprov + reprov + exam;
			pctgAprov = (aprov * 100) / totalSituacao;
			pctgReprov = (reprov * 100) / totalSituacao;
			pctgExam = (exam * 100) / totalSituacao;
			
			String text = "";
				   text += "Total de homens: "+masc+"("+pctgHomens+")\n"+"Total de mulheres: "+fem+"("+pctgMulheres+")\n\n"+"Alunos aprovados: "+aprov+"("+pctgAprov+")\n"
						   +"Alunos em exame: "+exam+"("+pctgExam+")\n"+"Alunos reprovados: "+reprov+"("+pctgReprov+")";
				   
			JOptionPane.showMessageDialog(null,  text, "", 1);
		case"sair":
					break;
		
		}
		
		escolha = JOptionPane.showInputDialog(null, "Digite o que deseja fazer\n ~ CADAS para cadastrar\n ~ EXC para excluir\n ~ ES para estat�sticas\n ~ SAIR para sair do sistema", "", 1);
		
		}while(!escolha.equals("sair"));
		
	}
	
}
