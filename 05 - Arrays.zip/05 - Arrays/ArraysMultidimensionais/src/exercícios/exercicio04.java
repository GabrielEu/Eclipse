package exerc�cios;

import java.util.Random;

import javax.swing.*;

public class exercicio04 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[][] matriz = new String[5][15];
		Random numeroGerado = new Random();
	
		//Construir corpo
		for(int linha = 0; linha < 5; linha++) {
			
			for(int coluna = 0; coluna < 15; coluna++) {
				
					matriz[linha][coluna] = " ";
				
			}
		}

		matriz[2][7] = "    "+numeroGerado.nextInt(10)+"    ";
		matriz[1][3] += "         ";
		matriz[3][3] += "         ";
		
		//Construir moldura
		for(int i = 0; i < 15; i++) {
			matriz[0][i] = "*";
			matriz[4][i] = "*";
		}
		
		for(int i = 0; i < 5; i++) {
			matriz[i][0] = "*";
			matriz[i][14] = "*";
		}
		
		//Escrever matriz
		String text = "";
		
		for(int linha = 0; linha < 5; linha++) {
			
			for(int coluna = 0; coluna < 15; coluna++) {
				
				text += matriz[linha][coluna]+" ";
				
				if(coluna == 14) {
					text += "\n";
				}
				
			}
		}
		
		JOptionPane.showMessageDialog(null, text, "", 1);
		
	}
	
}
