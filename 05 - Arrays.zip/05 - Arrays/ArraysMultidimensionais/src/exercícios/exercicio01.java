package exerc�cios;

import javax.swing.*;

public class exercicio01 {

	public static void main(String[] args) {
		
		//Vari�veis
		int[][] n = new int[5][6];
		int total = 0, media;
		int nImpares = 0, nPares = 0;
		
		
		for(int i = 0; i < 5; i++) {
			
				for(int i2 = 0; i2 < 6; i2++) {
					n[i][i2] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um n�mero", "", 3));
				}
				
		}
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 6; i2++) {
			
				if(n[i][i2] % 2 == 0) {
					nPares++;
				}
			}
		}
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 6; i2++) {
			
				if((n[i][i2] % 2) == 1) {
					nImpares++;
				}
			}
		}
		
		JOptionPane.showMessageDialog(null, "S�o "+nPares+" n�meros pares e "+nImpares+" n�meros �mpares", "", 1);
		
		//Conseguir total
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 6; i2++) {
				total += n[i][i2];
			}
		}
		
		//Media
		media = (total * 100) / 30;
		
		JOptionPane.showMessageDialog(null, "A m�dia dos n�meros � de "+media, "", 1);
		
		//Maior ou igual a m�dia
		int maiorAMedia, igualAMedia;
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 6; i2++) {
				
				if(n[i][i2] > media) {
					maiorAMedia = n[i][i2];
				} else if(n[i][2] == media) {
					igualAMedia = n[i][i2];
				}
			}
		}
		
		//Exibir matriz
		String texto = "";
		int contar = 0;
		
		for(int i = 0; i < 5; i++) {
			
			for(int i2 = 0; i2 < 6; i2++) {
				
				texto += n[i][i2]+"             ";
			
				contar++;
				
				if(contar == 5) {
					texto += "\n";
					contar = 0;
				}
			}
		}
		
		JOptionPane.showMessageDialog(null, texto, "", 1);
		
	}
	
}
