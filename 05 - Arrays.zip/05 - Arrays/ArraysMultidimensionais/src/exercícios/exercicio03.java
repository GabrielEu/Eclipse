package exerc�cios;

import javax.swing.*;

public class exercicio03 {

	public static void main(String[] args) {
		
		//Vari�veis
		int[][] n = new int[2][3];
		int contar = 0;
		
		
		//Atribuir valores
		for(int i = 0; i < 2; i++) {
			
			for(int i2 = 0; i2 < 3; i2++) {
				
				contar++;
				n[i][i2] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o "+contar+"� n�mero", "", 1));
			}
		}
		
		//Escrever matriz
		String text = "";
		
		for(int linha = 0; linha < 2; linha++) {
			
			for(int coluna = 0; coluna < 3; coluna++) {
				
				text += n[linha][coluna]+"           ";

			}
		text += "\n";
		}
		
		//Exibir matriz
		JOptionPane.showMessageDialog(null, text, "", 1);
		
		text = "";
		
		//Escrever matriz transposta	
		for(int coluna = 0; coluna < 3; coluna++) {
					
			for(int linha = 0; linha < 2; linha++) {
						
				text += n[linha][coluna]+"           ";

			}
		text += "\n";
		}
				
		//Exibir matriz transposta
		JOptionPane.showMessageDialog(null, text, "", 1);
		
	}	
}
