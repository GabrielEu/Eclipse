package exerc�cios;

import javax.swing.*;

public class exercicio06 {

	public static void main(String[] args) {
	
		//Vari�veis
		String[][] matriz = new String[3][3];
		int jogada;
		int contar = 0;
		String text;
		boolean valida = false;
		
		//Atribuir valores a matriz
		text = "";
		for(int linha = 0; linha < 3; linha++) {
			
			for(int coluna = 0; coluna < 3; coluna++) {
				
				contar++;
				
				matriz[linha][coluna] = contar+"";
				
				//Criar desenho
				if((contar == 3) || (contar == 6)){
					text += matriz[linha][coluna];
					text += "\n---------------------------\n";
					
				} else if(contar == 9){
					text += matriz[linha][coluna];
				} else {
					text += matriz[linha][coluna]+"      |      ";
				}
				
				
				
			}
			
		}

		//Informar jogadores
		JOptionPane.showMessageDialog(null, "- Jogador 1 ==> X\n- Jogador 2 ==> O", "*****  JOGO DA VELHA  *****", 1);
		
		//La�o jogo
		for(int i = 0; i < 9; i = i) {
			
			jogada = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o n�mero em que deseja jogar\n\n"+text+"\n\n", "*****  JOGADOR 1  *****", 1));
			i++;
			
			if(jogada == 1) {
				matriz[0][0] = "X";
			} else if(jogada == 2) {
				matriz[0][1] = "X";
			} else if(jogada == 3) {
				matriz[0][2] = "X";
			} else if(jogada == 4) {
				matriz[1][0] = "X";
			} else if(jogada == 5) {
				matriz[1][1] = "X";
			} else if(jogada == 6) {
				matriz[1][2] = "X";
			} else if(jogada == 7) {
				matriz[2][0] = "X";
			} else if(jogada == 8) {
				matriz[2][1] = "X";
			} else{
				matriz[2][2] = "X";
			}
				
			//Atribuir valores a matriz
			text = "";
			contar = 0;
			for(int linha = 0; linha < 3; linha++) {
					
				for(int coluna = 0; coluna < 3; coluna++) {
					contar++;
						
					//Criar desenho
					if((contar == 3) || (contar == 6)){
						text += matriz[linha][coluna];
						text += "\n---------------------------\n";
						
					} else if(contar == 9){
						text += matriz[linha][coluna];
					} else {
						text += matriz[linha][coluna]+"      |      ";
					}	
				}
					
			}
			
			//Vit�ria 1� jogador
			if((matriz[0][0].equals("X")) && (matriz[0][1].equals("X")) && (matriz[0][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else if((matriz[0][0].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else if((matriz[1][0].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[2][0].equals("X")) && (matriz[2][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][0].equals("X")) && (matriz[1][0].equals("X")) && (matriz[2][0].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][1].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][1].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][2].equals("X")) && (matriz[1][2].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 1 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else {
				
			}
			
			//Jogador 2
			jogada = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o n�mero em que deseja jogar\n\n"+text+"\n\n", "*****  JOGADOR 2  *****", 1));
			i++;
			
			if(jogada == 1) {
				matriz[0][0] = "O";
			} else if(jogada == 2) {
				matriz[0][1] = "O";
			} else if(jogada == 3) {
				matriz[0][2] = "O";
			} else if(jogada == 4) {
				matriz[1][0] = "O";
			} else if(jogada == 5) {
				matriz[1][1] = "O";
			} else if(jogada == 6) {
				matriz[1][2] = "O";
			} else if(jogada == 7) {
				matriz[2][0] = "O";
			} else if(jogada == 8) {
				matriz[2][1] = "O";
			} else{
				matriz[2][2] = "O";
			}
				
			//Atribuir valores a matriz
			text = "";
			contar = 0;
			for(int linha = 0; linha < 3; linha++) {
					
				for(int coluna = 0; coluna < 3; coluna++) {
					contar++;
						
					//Criar desenho
					if((contar == 3) || (contar == 6)){
						text += matriz[linha][coluna];
						text += "\n---------------------------\n";
						
					} else if(contar == 9){
						text += matriz[linha][coluna];
					} else {
						text += matriz[linha][coluna]+"      |      ";
					}
				}
			}
			
			
			//Vit�ria 1� jogador
			if((matriz[0][0].equals("X")) && (matriz[0][1].equals("X")) && (matriz[0][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else if((matriz[0][0].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else if((matriz[1][0].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[2][0].equals("X")) && (matriz[2][1].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][0].equals("X")) && (matriz[1][0].equals("X")) && (matriz[2][0].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][1].equals("X")) && (matriz[1][1].equals("X")) && (matriz[2][1].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			}  else if((matriz[0][2].equals("X")) && (matriz[1][2].equals("X")) && (matriz[2][2].equals("X"))) {
				JOptionPane.showMessageDialog(null, "Jogador 2 ganhou!\n\n"+text, "", 1);
				valida = true;
				break;
			} else {
				
			}
		
		
		}

		if(valida == false) {
		JOptionPane.showMessageDialog(null, "Empate!\n\n"+text, "", 1);
		}
		
	}
}
