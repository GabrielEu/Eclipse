package exercicioProva;

import java.util.Random;

import javax.swing.*;

public class exe {

	public static void main(String[] args) {
		
		
		//Vari�veis
		int[] n = new int[5];
		Random r = new Random();
		String text = ""; 
		
		//La�o atribuir valores aleat�rios
		for(int i = 0; i < 5; i++) {
			
			n[i] = r.nextInt(21);
			text += n[i]+"\n";
		}
		
	JOptionPane.showMessageDialog(null, text, "", 1);
		
	}
	
}
