package exercicio07;

import javax.swing.*;

public class exercicio07 {

	public static void main(String[] args) {
		
		//Vari�veis
		int[] num = new int[7];
		int[] compararNum = new int[7];
		int i2;
		int loop = 0;
		
		
		
		//aviso
		JOptionPane.showMessageDialog(null, "Informe 7 n�meros", "", 1);
		
		//la�o
		for(int i = 0; i < 7; i++) {
			loop = 0;
			num[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o "+(i+1)+" n�mero", "", 3));
			
				//La�o para comparar
				do {
					if(num[i] == compararNum[loop]) {
						JOptionPane.showMessageDialog(null, "Esse n�mero j� foi informado, informe outro", "", 0);
						num[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o "+(i+1)+" n�mero", "", 3));
						loop += -1;
					}
					
				loop++;
				}while(loop != 7);
				
			compararNum[i] = num[i];
		}
		
		//Exibir
		String texto = "";
		for(i2 = 0; i2 < 7; i2++) {
			
					texto += num[i2]+"\n";
		
		}
		
		JOptionPane.showMessageDialog(null, texto, "", 1);
		
	}
	
}
