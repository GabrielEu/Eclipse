package exercicio09;

import javax.swing.*;

public class execicio09 {

	public static void main(String[] args) {
	
		//Vari�veis
		String[] produto = new String[20];
		int[] valor = new int[20], quantidade = new int[20];
		Object[] escolha = {"Cadastrar produto", "Listar produtos", "Alterar produtos", "Excluir produtos", "Sair"};
		Object menu = "";
		String[] retirarProdutosIguais = new String[20];
		String text = "", alterarProduto, excluirProdutos;
		boolean valida = false;
		int permissaoExcluir;
		
		menu = JOptionPane.showInputDialog(null, "Escolha o que deseja fazer", "", JOptionPane.PLAIN_MESSAGE, null, escolha, "");
		
		do {

			if(menu.equals("Cadastrar produto")) {
				int i = 1;
				produto[i] = JOptionPane.showInputDialog(null, "Informe o produto que deseja cadastrar", "*****  CADASTRAR  *****", 1);
				valor[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o valor que deseja cadastrar", "*****  CADASTRAR  *****", 1));
				quantidade[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade que deseja cadastrar", "*****  CADASTRAR  *****", 1));
			} else if(menu.equals("Listar produtos")) {
				text = "";

				for(int i = 0; i < 20; i++) {
					
					if(produto[i] != null) {
						text += "Produto: "+produto[i]+"\nPre�o: "+valor[i]+"\nQuantidade: "+quantidade[i]+"\n\n";
					}
						//A LISTAGEM � DUPLICADA QUANDO APERTA DENOVO
					
					
				}
				
				JOptionPane.showMessageDialog(null, text, "", 1);
				
			} else {
				
			}
		

			//Alterar produtos
			if(menu.equals("Alterar produtos")) {
				alterarProduto = JOptionPane.showInputDialog(null, "Informe o produto que deseja alterar", "", 1);
				
			  do {
				for(int i = 0; i < 20; i++) {
					
					if(alterarProduto.equals(produto[i])) {
						produto[i] = JOptionPane.showInputDialog(null, "Informe o produto que deseja alterar", "*****  CADASTRAR  *****", 1);
						valor[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o valor que deseja alterar", "*****  CADASTRAR  *****", 1));
						quantidade[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade que deseja alterar", "*****  CADASTRAR  *****", 1));
						
						produto[i] = alterarProduto;
						valida = true;
					}
				} 
			
				JOptionPane.showMessageDialog(null, "Produto n�o encontrado, tente novamente", "*****  ERROR  *****", 0);
				
			  }while(valida == false);
			
			//Excluir produtos
			} else if(menu.equals("Excluir produtos")) {
				excluirProdutos = JOptionPane.showInputDialog(null, "Informe o produto que deseja excluir", "", 1);
				
				  for(int i = 0; i < 20; i++) {
					  
					if(excluirProdutos.equals(produto[i])) {
						permissaoExcluir = JOptionPane.showConfirmDialog(null, "Realmente deseja excluir "+produto[i]+"?", "", 1);
							
							if(permissaoExcluir == 0) {
								produto[i] = null;
							}
					}
				  }
			}
			
			menu = JOptionPane.showInputDialog(null, "Escolha o que deseja fazer", "", JOptionPane.PLAIN_MESSAGE, null, escolha, "");

		}while(!menu.equals("Sair"));
			
	}
}
