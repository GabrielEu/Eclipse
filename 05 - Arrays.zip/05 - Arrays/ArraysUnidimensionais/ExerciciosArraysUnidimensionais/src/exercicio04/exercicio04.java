package exercicio04;

import javax.swing.*;

public class exercicio04 {

	public static void main(String[] args) {

		//Vari�veis
		String opcao;
		String[] nome = new String[30];
		int nomeCont = 0;
		String[] gabarito = new String[10];
		String[] respAlunos = new String[10];
		int continuar = 0;
		boolean valida;
		int[] acertos = new int[30];
		int maiorAcerto;
		String maiorNomeAcerto;
		
		//Loop respostas corretas
		for(int loop = 0; loop < 10; loop++) {
			valida = false;
				
			do{ 
				opcao = JOptionPane.showInputDialog(null, "Informe a "+(loop+1)+"� quest�o", "", 3);
				
				if((opcao.equals("A")) || (opcao.equals("B")) || (opcao.equals("C")) || (opcao.equals("D"))) {
					gabarito[loop] = opcao;
					valida = true;
				} else{
					JOptionPane.showMessageDialog(null, "Resposta inv�lida", "", 0);
				}
				
			} while(valida == false);
				
			}
			
		JOptionPane.showMessageDialog(null, "O gabarito est� pronto!", "", 1);
		
		
		//Loop respostas alunos
	do{ 
		nome[nomeCont] = JOptionPane.showInputDialog(null, "Digite seu nome", "", 3);
		
		for(int loop = 0; loop < 10; loop++) {
			valida = false;
			
			do {
				opcao = JOptionPane.showInputDialog(null, "Informe a "+(loop+1)+"� quest�o", "", 3);
			
				if((opcao.equals("A")) || (opcao.equals("B")) || (opcao.equals("C")) || (opcao.equals("D"))) {
					valida = true;
					respAlunos[loop] = opcao;
				} else {
					JOptionPane.showMessageDialog(null, "Resposta inv�lida", "", 0);
				}
			
				if(opcao.equals(gabarito[loop])) {
					acertos[nomeCont]++;
				}
			
		} while(valida == false);
		
		}
		
		nomeCont++;
		continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar?", "", 1);
		
	}while(continuar == 0);
		
	String texto =  ("");
	
	//M�todo bolha
			for(int i1 = 0; i1 < 29; i1++){
				
				for(int i2 = i1+1; i2 < 30; i2++){
					
					if(acertos[i2] > acertos[i1]){
						maiorAcerto = acertos[i1];
						acertos[i1] = acertos[i2];
						acertos[i2] = maiorAcerto;
						
						maiorNomeAcerto = nome[i1];
						nome[i1] = nome[i2];
						nome[i2] = maiorNomeAcerto;
					}
					
				}
				
			}
			
		texto += "Resultado da prova:\n\n";
		int ranking = 1;
		
			for(int loop = 0; loop < 30; loop++) {
				
				if(nome[loop] != null) {
					texto += ranking+"� lugar � "+nome[loop]+" com nota "+acertos[loop]+"\n";
				}
				
			ranking++;
			
			}
						
						
		JOptionPane.showMessageDialog(null, texto, "", 1);
			
		
		
		
		
		
	}
}
	

