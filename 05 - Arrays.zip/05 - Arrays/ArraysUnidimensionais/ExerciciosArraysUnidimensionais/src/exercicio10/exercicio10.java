package exercicio10;

import javax.swing.*;

public class exercicio10 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[] nome = new String[150], sobrenome = new String[150];
		int[][] nascimento = new int[3][150]; //0 - dia   *   1 - m�s   *   2 - ano;
		int perguntaSalvar = 0;
		String[][] info = new String[4][150];
			/*0 = email
			1 = celular
			2 = endere�o 
			3 = categoria*/
		
		
		//Salvar conwtatos
		boolean valida = true;
		
		  for(int i = 0; perguntaSalvar == 0; i++) {
			nome[i] = JOptionPane.showInputDialog(null, "Informe o nome do "+(i+1)+"� contato", "", 1);
				while(nome[i].equals("")) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
				
					nome[i] = JOptionPane.showInputDialog(null, "Informe o nome do "+(i+1)+"� contato", "", 1);
				}
				
				
			sobrenome[i] = JOptionPane.showInputDialog(null, "Informe o sobrenome do "+(i+1)+"� contato", "", 1);
				while(sobrenome[i] == null) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
			
					sobrenome[i] = JOptionPane.showInputDialog(null, "Informe o sobrenome do "+(i+1)+"� contato", "", 1);
				}
				
				
			JOptionPane.showMessageDialog(null, "Informe a data de nascimento", "", 1);
			
			nascimento[0][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o m�s do "+(i+1)+"� contato", "dd/mm/aaaa"));
				while(nascimento[0][i] == 0) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
			
					nascimento[0][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o m�s do "+(i+1)+"� contato", "dd/mm/aaaa"));
				}
				
			nascimento[1][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do "+(i+1)+"� contato", "dd/mm/aaaa"));
				while(nascimento[1][i] == 0) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
			
					nascimento[1][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do "+(i+1)+"� contato", "dd/mm/aaaa"));
				}
				
			nascimento[2][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ano do "+(i+1)+"� contato", "dd/mm/aaaa"));
				while(nascimento[2][i] == 0) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
			
					nascimento[2][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ano do "+(i+1)+"� contato", "dd/mm/aaaa"));
				}
			
				
			info[0][i] = JOptionPane.showInputDialog(null, "Informe o email do "+(i+1)+"� contato", "", 1);
				while(info[0][i] == null) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
		
					info[0][i] = JOptionPane.showInputDialog(null, "Informe o email do "+(i+1)+"� contato", "", 1);
				}
				
				
			info[1][i] = ""+JOptionPane.showInputDialog(null, "Informe o n�mero do "+(i+1)+"� contato", "", 1);
				while(info[1][i] == null) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
		
					info[1][i] = ""+JOptionPane.showInputDialog(null, "Informe o n�mero do "+(i+1)+"� contato", "", 1);
				}
				
				
			info[2][i] = JOptionPane.showInputDialog(null, "Informe o endere�o do "+(i+1)+"� contato", "", 1);
				while(info[2][i] == null) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
		
					info[2][i] = JOptionPane.showInputDialog(null, "Informe o endere�o do "+(i+1)+"� contato", "", 1);
				}
				
				
			info[3][i] = JOptionPane.showInputDialog(null, "Informe a categoria do contato", "", 1);
				while(info[3][i] == null) {
					JOptionPane.showMessageDialog(null, "N�o deixe em branco!", "*****  ERROR  *****", 0);
		
					info[3][i] = JOptionPane.showInputDialog(null, "Informe a categoria do contato", "", 1);
				}
		  
				perguntaSalvar = JOptionPane.showConfirmDialog(null,  "Deseja salvar um novo contato?", "", 1);
				
		  }
		
		//Alterar informa��es
		String alterar;
		int perguntaAlterar;
		Object[] alterarEscolha = {"Nome", "Sobrenome", "Data de nascimento", "Email", "N�mero", "Endere�o"};
		
		perguntaAlterar = JOptionPane.showConfirmDialog(null,  "Gostaria de alterar algum contato?", "", 1);

			
			for(int i = 0; perguntaAlterar == 0; i++) {
				
				alterar = JOptionPane.showInputDialog(null, "Informe o nome do contato que gostaria de alterar", "", 3);
			
				if(alterar.equals(nome[i])) {
					Object escolha = (JOptionPane.showInputDialog(null, "Escolha a informa��o que ir� de alterar", "", JOptionPane.PLAIN_MESSAGE, null, alterarEscolha, ""));
				
					if(escolha.equals("Nome")) {
						nome[i] = JOptionPane.showInputDialog(null, "Informe o nome do "+i+"� contato", "", 1);
					} else if(escolha.equals("Sobrenome")){
						nome[i] = JOptionPane.showInputDialog(null, "Informe o nome do "+i+"� contato", "", 1);
					} else if(escolha.equals("Data de nascimento")) {
						nascimento[0][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do"+i+"� contato", " 94 "));
						nascimento[1][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o m�s do"+i+"� contato", " 94 "));
						nascimento[2][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ano do"+i+"� contato", " 94 "));
						
					} else if(escolha.equals("Email")) {
						info[0][i] = JOptionPane.showInputDialog(null, "Informe o email do contato", "", 1);
					} else if(escolha.equals("N�mero")) {
						info[1][i] = ""+JOptionPane.showInputDialog(null, "Informe o n�mero do contato", "", 1);
					} else if(escolha.equals("Endere�o")){
						info[2][i] = JOptionPane.showInputDialog(null, "Informe o endere�o do contato", "", 1);
					} else {
					
					}
					
					perguntaAlterar = JOptionPane.showConfirmDialog(null,  "Gostaria de alterar novamente?", "", 1);
				}	else{
					JOptionPane.showMessageDialog(null,  "Contato n�o encontrado");
					
			}
				perguntaAlterar = JOptionPane.showConfirmDialog(null,  "Gostaria de alterar novamente?", "", 1);
			}
		
		//Excluir contato
		int perguntaExcluir, permissaoExcluir;
		String excluir;
		
		perguntaExcluir = JOptionPane.showConfirmDialog(null, "Deseja excluir algum contato?", "", 1);
	
			
			for(int i = 0; perguntaExcluir == 0; i++) {
				
				excluir = JOptionPane.showInputDialog(null, "Informe o nome de quem deseja excluir o contato", "", 1);
				
				
				if(excluir.equals(nome[i])) {
					permissaoExcluir = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir?", "", 1);
						
						if(permissaoExcluir == 0) {
							nome[i] = null;
							
							permissaoExcluir = JOptionPane.showConfirmDialog(null, "Deseja salvar um novo contato?", "", 1);
							
								if(permissaoExcluir == 0) {
									nome[i] = JOptionPane.showInputDialog(null, "Informe o nome do "+(i+1)+"� contato", "", 1);
									sobrenome[i] = JOptionPane.showInputDialog(null, "Informe o sobrenome do "+(i+1)+"� contato", "", 1);
									nascimento[0][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do"+i+"� contato", " 94 "));
									nascimento[1][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do"+i+"� contato", " 94 "));
									nascimento[2][i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o dia do"+i+"� contato", " 94 "));
									
									info[0][i] = JOptionPane.showInputDialog(null, "Informe o email do contato", "", 1);
									info[1][i] = ""+JOptionPane.showInputDialog(null, "Informe o n�mero do contato", "", 1);
									info[2][i] = JOptionPane.showInputDialog(null, "Informe o endere�o do contato", "", 1);
									info[3][i] = JOptionPane.showInputDialog(null, "Informe a categoria do contato", "", 1);
									
			perguntaExcluir = JOptionPane.showConfirmDialog(null, "Deseja excluir mais algum contato?", "", 1);
								}
						}
				} else{
					
					JOptionPane.showMessageDialog(null,  "Contato n�o encontrado, tente novamente", "", 1);
					
					while(!excluir.equals(nome[i])) {
						
						excluir = JOptionPane.showInputDialog(null, "Informe o nome de quem deseja excluir o contato", "", 1);
				
					} 
				}
			}
		
		///Pesquisar contatos atrav�s dos nomes
		String pesquisar;
		int perguntaPesquisar;
		
		perguntaPesquisar = JOptionPane.showConfirmDialog(null, "Deseja pesquisar algum contato?", "", 1);
			
			pesquisar = JOptionPane.showInputDialog(null, "Informe o nome de quem deseja pesquisar", "", 3);
			
			for(int i = 0; perguntaPesquisar == 0; i++) {
				
				if(pesquisar.equals(nome[i])) {
					JOptionPane.showMessageDialog(null, "Nome: "+nome[i]+" "+sobrenome[i]+"\nNascimento: "+nascimento[i]+"\nEmail: "+info[0][i]+"\nCelular: "+info[1][i]+
							"\nEndere�o: "+info[2][i], "", 1);
					
				} else {
					JOptionPane.showMessageDialog(null, "Contato n�o foi achado, tente novamente", "", 0);
				}
				
				
				perguntaPesquisar = JOptionPane.showConfirmDialog(null, "Deseja pesquisar novamente algum contato?", "", 1);
			}
		
		
		//Alterar categoria
		int perguntaAlterarCat;
		String pesquisarCat;
		
		perguntaAlterarCat = JOptionPane.showConfirmDialog(null, "Deseja alterar alguma categoria?", "", 1);
			
			pesquisarCat = JOptionPane.showInputDialog(null, "Informe o nome da categoria que voc� deseja pesquisar", "", 3);
					
				do{
					
					for(int i = 0; perguntaAlterarCat == 0; i++) {
						
						if(pesquisarCat.equals(info[3][i])) {
							pesquisarCat = JOptionPane.showInputDialog(null, "Informe o novo nome da categoaria", "", 3);
							
								if(pesquisarCat == null) {
								
									JOptionPane.showMessageDialog(null, "N�o deixe a categoria em branco!", "*****  ERROR  *****", 1);
									pesquisarCat = JOptionPane.showInputDialog(null, "Informe o novo nome da categoaria", "", 3);
									valida = false;
								} else{
									info[3][i] = pesquisarCat;
									valida = true;
								}


							info[3][i] = JOptionPane.showInputDialog(null, "Informe a categoria do contato", "", 1);
						}
						
						perguntaAlterarCat = JOptionPane.showConfirmDialog(null, "Deseja alterar novamente alguma categoria?", "", 1);
						
					}
					}while (valida == false);

				

		//Excluir categoria
		int perguntaExcluirCat;
		String pesquisarExcluirCat;
		
		perguntaExcluirCat = JOptionPane.showConfirmDialog(null,  "Deseja excluir alguma categoria?", "", 1);
			
			for(int i = 0; perguntaExcluirCat == 0; i++) {
				
				pesquisarExcluirCat = JOptionPane.showInputDialog(null, "Informe o nome da categoria que gostaria de excluir", "", 3);
				
				if(pesquisarExcluirCat.equals(info[3][i]) && (info[3][i] == null)) {
					
					info[3][i] = null;
					
				} else if(!pesquisarExcluirCat.equals(info[3][i])) {
					
					perguntaExcluirCat = JOptionPane.showConfirmDialog(null, "Categoria n�o encontrada. Gostaria de pesquisar novamente?", "*****  ERROR  *****", 3);
					break;
				}else if(pesquisarExcluirCat.equals(info[3][i]) && (info[3][i] != null)) {
					
					perguntaExcluirCat = JOptionPane.showConfirmDialog(null, "Categoria n�o pode ser excluida pois "+nome[i]+" est� cadastrado nela. Gostaria de pesquisar "
							+"novamente?", "*****  ERROR  *****", 3);
					break;
				} else {
				
				}
				
				perguntaExcluirCat = JOptionPane.showConfirmDialog(null,  "Deseja excluir mais alguma categoria?", "", 1);
			
			}
			
			//Aniversariantes
			int aniversario;
			int perguntaAniver = 0;
			String texto = "";
			
			aniversario = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o m�s do aniversariante", "", 3));
		
			for(int i = 0; perguntaAniver == 0; i++) {
				
				if(aniversario == nascimento[1][i]) {
					texto += "Nome: "+nome[i]+"\nData de nascimento: "+nascimento[0][i]+"/"+nascimento[1][i]+"/"+nascimento[2][i];
				}
				
				JOptionPane.showMessageDialog(null,  texto, "", 1);
				
				perguntaAniver = JOptionPane.showConfirmDialog(null, "Deseja procurar mais um aniversariante?", "", 1);
			}
			
			
		}
	}
