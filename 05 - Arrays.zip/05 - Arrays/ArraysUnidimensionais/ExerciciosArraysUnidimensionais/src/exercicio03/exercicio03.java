package exercicio03;

import javax.swing.*;

public class exercicio03 {

	public static void main(String[] args) {
	
	//Vari�veis
	int[] n = new int[5];
	String resposta;
	
	for(int loop = 0; loop < 5 ; loop++) {
		
		n[loop] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um n�mero", "", 3));
		
	}
	
	if(n[0] == 10) {
		resposta = ("O n�mero 10 est� na 1� posi��o");
	} else if(n[1] == 10) {
		resposta = ("O n�mero 10 est� na 2� posi��o");
	} else if(n[2] == 10) {
		resposta = ("O n�mero 10 est� na 3� posi��o");
	} else if(n[3] == 10) {
		resposta = ("O n�mero 10 est� na 4� posi��o");
	} else if(n[4] == 10){
		resposta = ("O n�mero 10 est� na 5� posi��o");
	} else{
		resposta = ("O n�mero 10 n�o est� presente em nenhuma posi��o");
	}
	
	System.out.println(resposta);

	
	
	}
}
