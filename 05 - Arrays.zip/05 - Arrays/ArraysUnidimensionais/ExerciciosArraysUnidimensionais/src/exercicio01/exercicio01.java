package exercicio01;

import javax.swing.*;

public class exercicio01 {

	public static void main(String[] args) {
		
		//Vari�veis
		Object[] calculo = {"Soma", "Subtra��o", "Multiplica��o", "Divis�o"};
		String texto = ("");
		int[] n1 = new int[10];
		int[] n2 = new int[10];
		int[] resultado = new int [10];
		
		Object escolha = JOptionPane.showInputDialog(null, "Escolha a opera��o", "", JOptionPane.PLAIN_MESSAGE, null, calculo, "");
		
		//La�o
		for(int loop = 0; loop <10; loop++) {
			String operacao;
			
			//Atribuir valor
			n1[loop] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um n�mero", "", 1));
			n2[loop] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe outro n�mero", "", 1));
		
			//Escolha da opera��o
			if(escolha.equals("Soma")){
				resultado[loop] = n1[loop] + n2[loop];
				operacao = (" + ");
			} else if(escolha.equals("Subtra��o")){
				resultado[loop] = n1[loop] - n2[loop];
				operacao = (" - ");
			} else if(escolha.equals("Multiplica��o")){
				resultado[loop] = n1[loop] * n2[loop];
				operacao = (" X ");
			} else{
				resultado[loop] = n1[loop] / n2[loop];
				operacao = (" / ");
			}
	
			//Criar texto
			texto += n1[loop]+" X "+n2[loop]+operacao+resultado[loop]+"\n";
					
			}    
		
		//Mostrar resultado
		System.out.println(texto);  //MEU DEUS EU FINALMENTE CONSEGUI ;----------;
	    
	    
	    }
		
	}
	

