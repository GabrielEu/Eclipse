package exercicio05;

import javax.swing.*;

public class exercicio05 {

	public static void main(String[] args) {
		
		//Vari�veis
		int[] numero = new int [15];
		int[] numeroCalculo = new int [15];
		int resultado = 0;
		String texto = "";
		int soma = 0;
		int obterMedia;
		int maiorNum;
		
		//Exibir aviso
		JOptionPane.showMessageDialog(null, "Informe 15 n�meros inteiros", "", 3);
		
		//La�o adquirir n�meros
		for(int loop = 0; loop < 15; loop++) {
			
			try {
				numero[loop] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o "+(loop+1)+"� n�mero", "", 3));
				numeroCalculo[loop] = numero[loop];
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Caractere inv�lido!", "", 0);
			}

		}
		
		//La�o opera��o
		for(int loop = 0; loop < 15; loop++) {
			
			resultado += ((numero[loop]+numero[loop])-numero[loop]);
		}
		
		//Mostrar resultados
		texto = "A soma de todos os n�meros �: "+resultado+"\n";
		
		//Exibir resultado
		JOptionPane.showMessageDialog(null, texto, "", 1);
		
		//Media
		for(int loop = 0; loop <15; loop++) {
			soma += numero[loop];
		}
		
		//Obter media
		obterMedia = soma/15;
		
		//Mostrar media
		JOptionPane.showMessageDialog(null, "A m�dia dos n�meros � de: "+obterMedia, "", 1);
		
	//La�o n�meros maiores que a m�dia
		
		//Resetar M�DIA e SOMA para reutilizar
		soma = 0;
		texto = "";
		
		for(int loop = 0; loop < 15; loop++) {
			
			//La�o
			if(numero[loop] > obterMedia) {
				texto += "                   \n"+numero[loop];
			}
		}
		
		
		//Exibir n�meros maiores que a m�dia
		JOptionPane.showMessageDialog(null, "Os n�meros maiores que a m�dia s�o:\n"+texto);
		
	//Verificar n�meros negativos
		
		//Resetar TEXTO para reutilizar
		texto = "";
		
		for(int loop = 0; loop < 15; loop++) {
			
			if(numero[loop] < 0) {
				texto += "\n"+numero[loop];
			}
		}
		
		//Exibir negativos
		JOptionPane.showMessageDialog(null, "N�meros negativos: \n"+texto, "", 1);
		
		
	//Verificar n�meros neutros
		
		//Resetar TEXTO para reutilizar
		texto = "";
				
		for(int loop = 0; loop < 15; loop++) {
			
			if(numero[loop] == 0) {
				texto += "\n"+numero[loop];
			}
		}
		
		//Exibir negativos
		JOptionPane.showMessageDialog(null, "N�meros neutros: \n"+texto, "", 1);
		
		
	//Verificar n�meros positivos
		
		//Resetar TEXTO para reutilizar
		texto = "";	
						
		for(int loop = 0; loop < 15; loop++) {
					
			if(numero[loop] > 0) {
				texto += "\n"+numero[loop];
			}
		}
		
		
		//Exibir positivos
		JOptionPane.showMessageDialog(null, "N�meros positivos: \n"+texto, "", 1);
		
		
		//La�o maior e menor n�mero
		for(int i1 = 0; i1 < 14; i1++) {
			
			for(int i2 = i1 + 1; i2 < 15; i2++){
				if(numero[i1] > numero[i2]) {
					maiorNum = numero[i1];
					numero[i1] = numero[i2];
					numero[i2] = maiorNum;
				}
			}
		}
		
		//Exibir maiores e menores
		JOptionPane.showMessageDialog(null, "O maio n�mero �: "+numero[14]+"\n"+"E o menor �: "+numero[1], "", 1);
	
		//N�meros pares
		String numeroPar = "";
		String numeroImpar = "";
		
		for(int i = 0; i < 15; i++) {
			if((numero[i] % 2) == 0) {
				numeroPar += "\n"+numero[i];
			} else {
				numeroImpar += "\n"+numero[i];
			}
			
		}
		
		//Exibir Impar e par
		JOptionPane.showMessageDialog(null,  "N�meros �mpares: "+numeroImpar, "", 1);
		
		JOptionPane.showMessageDialog(null,  " N�meros pares: "+numeroPar, "", 1);
	}
}
