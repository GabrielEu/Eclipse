package exercicio02;

import javax.swing.*;

public class exercicio02 {

	public static void main(String[] args) {
	
	//Vari�veis
	int[] n = new int[10];
	int[] texto = new int[10];
	
	//Atribuir valores
	for(int loop = 0; loop < 10; loop++) {
	
		
	n[loop] = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite um n�mero", "", 3));
	
	texto[loop] = n[loop];
	
	/*String texto += n[10];
			texto += n[10];*/
	
	
	}
	
	System.out.print(texto[9]+"\n");
	System.out.print(texto[8]+"\n");
	System.out.print(texto[7]+"\n");
	System.out.print(texto[6]+"\n");
	System.out.print(texto[5]+"\n");
	System.out.print(texto[4]+"\n");
	System.out.print(texto[3]+"\n");
	System.out.print(texto[2]+"\n");
	System.out.print(texto[1]+"\n");
	System.out.println(texto[0]+"\n");
	
	}
	
}