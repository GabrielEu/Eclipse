package exercicio06;

import javax.swing.*;

public class exercicio06 {

	public static void main(String[] args) {
		
		
		//Vari�veis
		int[] respostas = new int[10];
		int erradas = 0;
		int corretas = 0;
		int continuar = 0;
		int[] jogador = new int[10];
		String[] nomeJogador = new String[10];
		int i = 0;
		int melhorJogador;
		String nomeMelhorJogador;
		
		//La�o
	  do {
			
		//Reiniciar score
		corretas = 0;
		erradas = 0;
		
		//Incrementar �ndice
		i++;
			
		//Perguntas
		respostas[0] = JOptionPane.showConfirmDialog(null, "1� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[1] = JOptionPane.showConfirmDialog(null, "2� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[2] = JOptionPane.showConfirmDialog(null, "3� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[3] = JOptionPane.showConfirmDialog(null, "4� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[4] = JOptionPane.showConfirmDialog(null, "5� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[5] = JOptionPane.showConfirmDialog(null, "6� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[6] = JOptionPane.showConfirmDialog(null, "7� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[7] = JOptionPane.showConfirmDialog(null, "8� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[8] = JOptionPane.showConfirmDialog(null, "9� pergunta\n", "Verdadeiro ou falso?", 1);
		respostas[9] = JOptionPane.showConfirmDialog(null, "10� pergunta\n", "Verdadeiro ou falso?", 1);
			
		//Verificar acertos e erros
		if(respostas[0] == 1){
			erradas++;
		} else{
			corretas++;
		}
			
		if(respostas[1] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[2] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[3] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[4] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[5] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[6] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[7] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[8] == 1){
			erradas++;
		} else{
			corretas++;
		}
		
		if(respostas[9] == 1){
			erradas++;
		} else{
			corretas++;
		}
		

			
		//Exibir respostas
		JOptionPane.showMessageDialog(null, "Voc� acertou "+corretas+" e errou "+erradas, "", 1);
		
		//Score jogador
		nomeJogador[i] = JOptionPane.showInputDialog(null, "Informe seu nome", "", 1);
		jogador[i] = corretas;
		
		//Continuar ou terminar
		continuar = JOptionPane.showConfirmDialog(null, "Deseja jogar novamente?", "", 1);
		
		
	  }while(continuar == 0);
		
		//Bolha
		for(int i1 = 0; i1 < 10; i1++) {
			
			for(int i2 = i1 + 1; i2 < 9; i2++) {
				
				if(jogador[i1] > jogador[i2]) {
					
					melhorJogador = jogador[i1];
					jogador[i1] = jogador[i2];
					jogador[i2] = melhorJogador;
					
					nomeMelhorJogador = nomeJogador[i1];
					nomeJogador[i1] = nomeJogador[i2];
					nomeJogador[i2] = nomeMelhorJogador;
					
					
				}
			}
		}
		
		//Ranking
		String texto = "";
		int lugar = 1;
		
		for(int i3 = 9; i3 > 0; i3--) {
			
			if(jogador[i3] != 0) {
				texto += lugar+"� lugar: "+nomeJogador[i3]+" com "+jogador[i3]+" acertos\n";
				lugar++;
			}
		}
		
		//Exibir ranking
		JOptionPane.showMessageDialog(null, texto, "**** RANKING ****", 1);
		
		}
	}
