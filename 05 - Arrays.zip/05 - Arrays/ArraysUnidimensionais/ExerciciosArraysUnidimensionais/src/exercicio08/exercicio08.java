package exercicio08;

import javax.swing.*;

public class exercicio08 {

	public static void main(String[] args) {
		
		//Vari�veis
		String[] usuario = new String[3];
		String[] senha = new String[3];
		String loginUser;
		String loginPass;
		boolean valida = false;
		
		//Atribuir valores
		usuario[0] = "Ralf";
		usuario[1] = "Gabriel";
		usuario[2] = "ProWay";
		
		senha[0] = "ralff77";
		senha[1] = "awdawdawd";
		senha[2] = "pwww";
		
		//Logar
		loginUser = JOptionPane.showInputDialog(null, "Informe o usu�rio", "***** LOGIN  *****", 3);
		loginPass = JOptionPane.showInputDialog(null, "Informe a senha", "***** LOGIN  *****", 3);
		
		
		//Condi��o do loggin 
		for(int i = 0; i < 3; i++) {
			
			if((loginUser.equals(usuario[i])) && (loginPass.equals(senha[i]))){
				valida = true;
		}
		}
		
	  if(valida == false) {
		  JOptionPane.showMessageDialog(null, "Login incorreto", "", 0);
		
		loginUser = JOptionPane.showInputDialog(null, "Informe o usu�rio", "***** LOGIN  *****", 3);
		loginPass = JOptionPane.showInputDialog(null, "Informe a senha", "***** LOGIN  *****", 3);
	} 
	
		//Exibir logado
		JOptionPane.showMessageDialog(null, "Login efetuado com sucesso", "*****  LOGADO  ******", 1);		
			
		}
	}
