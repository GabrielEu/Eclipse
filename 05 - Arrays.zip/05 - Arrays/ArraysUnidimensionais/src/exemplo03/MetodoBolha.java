package exemplo03;

public class MetodoBolha{
	
	public static void main(String[] args) {

	//Vetor
	int[] numeros = {5, 3, 1, 8, 4};
	
	//Maior n�mero
	int maiorNum;
	
	//La�o01
	for(int i1 = 0; i1 < 4; i1++) {
		
		//La�o02
		for(int i2 = i1+1; i2 < 5; i2++) {
			
			if(numeros[i2] < numeros[i1]) {
				maiorNum = numeros[i1];
				numeros[i1] = numeros[i2];
				numeros[i2] = maiorNum;
			}
			
		}
		
	}
	
	for(int n : numeros) {
	System.out.println(n);
	}
	
	}
	
	
}
