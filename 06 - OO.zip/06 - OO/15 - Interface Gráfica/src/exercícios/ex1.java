package exerc�cios;

import javax.swing.JFrame;

public class ex1 {

	public static void main(String[] args) {
		
		JFrame construtor = new JFrame();
		construtor.setSize(500, 300);
		construtor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		construtor.setLocation(null);
		construtor.setLayout(null);
	}
	
}
