package exemplo02;

public class Principal {

	public static void main(String[] args) {
	
	Aluno a = new Aluno();
	a.menu();

	
	}
}
