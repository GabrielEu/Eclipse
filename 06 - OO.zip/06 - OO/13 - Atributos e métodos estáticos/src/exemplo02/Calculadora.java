package exemplo02;

public class Calculadora {

	//M�todo apra realizar a soma
	public static void somar(int n1, int n2) {
		
		System.out.println(n1+n2);
		
	}
	
	
}
