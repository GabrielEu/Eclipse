package exemplo02;

public class Main {

	public static void main(String[] args) {
		
		//Chamando m�todo est�tico
		Calculadora.somar(8, 10);;
		
		
	}
	
	
}
