package exemplo01;

public class Pessoa {

	//Atributo da classe
	private static int contador = 0;
	
	public void Pessoa() {
		contador++;
		
		System.out.println(contador);
	}
	
}
