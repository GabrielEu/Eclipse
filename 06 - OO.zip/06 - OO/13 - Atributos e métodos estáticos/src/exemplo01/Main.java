package exemplo01;

public class Main {

	public static void main(String[] args) {
		
		//Instanciar
		Pessoa p1 = new Pessoa();
		Pessoa p2 = new Pessoa();
		Pessoa p3 = new Pessoa();
		
		
	}
	
	
}
