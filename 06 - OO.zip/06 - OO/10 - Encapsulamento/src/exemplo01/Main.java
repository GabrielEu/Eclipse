package exemplo01;

public class Main {

	public static void main(String[] args) {
		
		//Instanciar
		Aluno a = new Aluno();
		a.obterDados();
		
		
	}

}
