package exemplo02;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		//Instanciar
		Pessoa p = new Pessoa();
		p.setNome("Eu");
		JOptionPane.showMessageDialog(null, p.getNome());
		
	}
	
}
