import javax.swing.*;

public class awd {

	public static void main(String[] args) {
		
		//Vari�veis
		loop
		
		
		for(int i = 1; i > 0; i++) {
			
			JOptionPane.showMessageDialog(null, null, "", 3));
			
			
		}
		
		
		
		
	}
	
}
