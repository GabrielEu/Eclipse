package exercicio03;

import javax.swing.*;

public class exercicio {

	public static void main(String[] args) {
	
	//Vari�veis
	String informar, radical = "";
	String ultimasLetras, text = "";
	int contar = 0;
	boolean validar = false;
	
	do {
		informar = JOptionPane.showInputDialog(null, "Informe um verbo terminado em AR", "", 3);
		
		for(int i = 0; i < informar.length(); i++) {
			
			contar++;
		}
		
		//Pegar �ltimas letras
		ultimasLetras = informar.substring(contar - 2);
		
		//Validar verbo
		if(ultimasLetras.equals("ar")) {
			validar = true;
		} else {
			JOptionPane.showMessageDialog(null, "Verbo inv�lido, tente novamente", "*****  ERROR  *****", 3);
			contar = 0;
		}
	
	}while(validar == false);
	
	//Escrever radical da palavra
	for(int i = 0; i < (contar - 2); i++) {
		radical += informar.charAt(i);
	}
	
	text += "Eu "+radical+"o\n";
	text += "Tu "+radical+"as\n";
	text += "Ele "+radical+"a\n";
	text += "N�s "+radical+"amos\n";
	text += "V�s "+radical+"�is\n";
	text += "Eles "+radical+"am";
	
	JOptionPane.showMessageDialog(null, text, "", 1);

	}
}
