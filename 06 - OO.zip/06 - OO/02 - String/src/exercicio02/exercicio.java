package exercicio02;

import javax.swing.*;

public class exercicio {

	public static void main(String[] args) {
		
		//Vari�veis
		String informar, separarLetras;

		int vogais = 0;
		
		informar = JOptionPane.showInputDialog(null, "Informe uma palavra", "", 3);
		
		for(int i = 0; i < informar.length(); i++) {
			
			separarLetras = String.valueOf(informar.charAt(i));
			
				if(separarLetras.equals("a")) {
					vogais++;
				} else if(separarLetras.equals("e")){
					vogais++;
				} else if(separarLetras.equals("i")) {
					vogais++;
				} else if(separarLetras.equals("o")) {
					vogais++;
				} else if(separarLetras.equals("u")) {
					vogais++;
				}
		}
		
	JOptionPane.showMessageDialog(null, "S�o "+vogais+" vogais");
		
	}
	
}
