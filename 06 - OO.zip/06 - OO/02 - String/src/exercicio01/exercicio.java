package exercicio01;

import javax.swing.JOptionPane;

public class exercicio {

	public static void main(String[] args) {
		
		//Vari�veis
		String palavra, text = "";
		char[] letras = new char[20];
		String[] letrasComparar = new String[20];
		int variar = 0, contarLoop;
		
		palavra = JOptionPane.showInputDialog(null, "Digite uma palavra", "", 1);
		
		//contarLoop = palavra.length();
		
		for(int i = 0; i < palavra.length(); i++) {
			letras[i] = palavra.charAt(i);
		}
		
		for(int i = 0; i < palavra.length(); i++) {
			
			variar++;
			letrasComparar[i] = String.valueOf(letras[i]);
			
			//Validar a palavra
			if((variar % 2) == 0) {
				
				if(!letrasComparar[i].equals("")) {
					text += letrasComparar[i].toUpperCase();
				}
				
			} else {
				
				if(!letrasComparar[i].equals("")) {
					text += letrasComparar[i].toLowerCase();
				}
			}
			
		}
		
		
		JOptionPane.showMessageDialog(null, text);
	
	}
}
