package exercicio07;

import javax.swing.*;

public class System {
	
	//Vari�veis
	String informarLetra, text;
	String[] letraRepetida = new String[7], letraCerta = new String[7];
	int contarJogada = 0, respostaErrada = 0;
	int i;
	
	//Atribuir letras
	public void atribuirLetras() {
		letraCerta[0] = "E";
		letraCerta[1] = "S";
		letraCerta[2] = "T";
		letraCerta[3] = "U";
		letraCerta[4] = "D";
		letraCerta[5] = "A";
		letraCerta[6] = "R";
	}
	
	//Pedir letra
	public void pedirLetra() {
		
		text = "\n_______";
		
		for(i = 0; i < 7; i++) {
		
			informarLetra = JOptionPane.showInputDialog(null, "Informe a "+(i+1)+" letra"+text, "", 3);
			letraRepetida[i] = informarLetra;
			contarJogada++;
			
			if((informarLetra.equals(letraCerta[i])) && (contarJogada == 1)) {
				text = "\nE______";
			
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 2)) {
				text = "\nES_____";
			
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 3)) {
				text = "\nEST____";
			
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 4)) {
				text = "\nESTU___";
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 5)) {
				text = "\nESTUD__";
			
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 6)) {
				text = "\nESTUDA_";
			
			} else if((informarLetra.equals(letraCerta[i])) && (contarJogada == 7)) {
				text = "\nESTUDAR";
			} else {
				i--;
				contarJogada--;
				respostaErrada++;
				JOptionPane.showMessageDialog(null, "Letra errada, tente novamente", "*****  ERROU  *****", 0);
			}
		
			if(respostaErrada == 6) {
				i = 7;
			}
		
		}
	}
	
	//Exibir t�rmino
	public void exibirVitoria() {
		
		if(respostaErrada == 6) {
			JOptionPane.showMessageDialog(null, "Game over", "*****  FIM DE JOGO  *****", 0);
		} else {
			JOptionPane.showMessageDialog(null, "Parab�ns :)", "", 1);
		}
	}
	
	
}