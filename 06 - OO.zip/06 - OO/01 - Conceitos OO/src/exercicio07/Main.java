package exercicio07;

public class Main {

	public static void main(String[] args) {

		System e = new System();
		e.atribuirLetras();
		e.pedirLetra();
		e.exibirVitoria();
		
		
		
		
	}

}
