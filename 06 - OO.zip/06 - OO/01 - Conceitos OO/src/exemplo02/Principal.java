package exemplo02;

public class Principal {

	public static void main(String[] args) {

		
		//Instanciar aluno
		Aluno a = new Aluno();
		a.laco();
		a.exibirDados();
		
	}

}
