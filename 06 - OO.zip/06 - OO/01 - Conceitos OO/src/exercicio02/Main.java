package exercicio02;

public class Main {

	public static void main(String[] args) {
		
		Info apresentar = new Info();
		apresentar.nome();
		apresentar.idade();
		apresentar.altura();
		apresentar.peso();
		apresentar.laco();
		
		apresentar.jogadoresCadastrados();
		apresentar.maiorJogador();
		apresentar.jogadorMaisVelho();
		apresentar.jogadorMaisPesado();
		apresentar.MediaAltura();
		
	}
}
