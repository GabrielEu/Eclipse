package exercicio02;

import javax.swing.JOptionPane;

public class Info {
		
	//Vari�veis
	String informarNome, nomeMaiorJog, nomeMaiorIdade, nomeMaiorPeso;
	double informarAltura, alturaMaiorJog, maiorAltura, informarPeso, totalAltura = 0, maiorIdade, idadeMaisVelho, maiorPeso, mediaAltura;
	int informarIdade, jogadores = 0;
	boolean loop = false;
	
	
	//Nome
	public String nome() {
	
		informarNome = JOptionPane.showInputDialog(null, "Informe seu nome", "", 3);
		
		jogadores++;
		
		if((informarNome.equals("SAIR")) || (informarNome.equals("sair"))){
			loop = false;
		} else {								//Ta considerando SAIR como um nome
			loop = true;
		}
		
		return informarNome;
		
	}
		
	//Altura
	public double altura() {
		
		informarAltura = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua altura", "", 3));
		
		totalAltura = informarAltura;
		
		if(informarAltura > maiorAltura) {
			
			nomeMaiorJog = informarNome;
			alturaMaiorJog = informarAltura;
			
		}
		
		
		return informarAltura;		
	}
	
	//Idade
	public int idade() {
		
		informarIdade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe sua idade", "", 3));
		
		if(informarIdade > maiorIdade) {
			
			idadeMaisVelho = informarIdade;
			nomeMaiorIdade = informarNome;
			
		}
		
		
		return informarIdade;
	}

	
	
	
	//Peso
	public double peso() {
		
		informarPeso = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe seu peso", "", 3));
		
		if(informarPeso > maiorPeso) {
			
			maiorPeso = informarPeso;
			nomeMaiorPeso = informarNome;
			
		}
		
		
		return informarPeso;
	}
	
	//La�o
	public void laco() {
		
		while(loop == true) {
	
			nome();
			idade();
			altura();
			peso();
		}
	}
	
	//Jogadores cadastrados
	public void jogadoresCadastrados() {
		
		JOptionPane.showMessageDialog(null, "Foram "+jogadores+" jogadores cadastrados", "", 1);
		
	}
	
	//Nome e altura maior jogadores
	public void maiorJogador(){
		
		JOptionPane.showMessageDialog(null, "O maior jogador � "+nomeMaiorJog+" com a altura de "+alturaMaiorJog+" metros", "", 1);
		
	}
	
	//Nome e idade do jogador mais velho
	public void jogadorMaisVelho(){
		
		JOptionPane.showMessageDialog(null, "O jogador mais velho � "+nomeMaiorIdade+" com "+idadeMaisVelho+" anos");
		
	}
	
	//Nome e peso do jogador mais pesado
	public void jogadorMaisPesado() {
		
		JOptionPane.showMessageDialog(null, "O jogador mais pesado � "+nomeMaiorPeso+" com "+maiorPeso+"KG");
		
	}
	
	//M�dia de altura dos jogadores
	public void MediaAltura(){
		
		mediaAltura = (totalAltura * 100) / jogadores;
		
		JOptionPane.showMessageDialog(null, "A m�dia de altura dos jogadores � de "+mediaAltura+" metros");
		
		
	}
	
	
}

