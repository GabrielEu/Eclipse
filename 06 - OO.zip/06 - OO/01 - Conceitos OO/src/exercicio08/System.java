package exercicio08;

import javax.swing.*;

public class System {

	//Vari�veis
	int num, contar;
	String text = "";
	
	//Pedir n�mero
	public void pedirNum() {
			num = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um n�mero"));
	}
		
	//Exibir antecessores
	public void exibirAnte() {
		
		for(int i = 0; i < 10; i++) {
			contar++;
			text += (num-contar)+"\n";
		}
		
		JOptionPane.showMessageDialog(null, "Antecessores: "+text, "", 1);
		text = "";
		contar = 0;
	}
	
	//Exibir sucessores
	public void exibirSuc() {
		
		for(int i = 0; i < 10; i++) {
			contar++;
			text += (num+contar)+"\n";
		}
		JOptionPane.showMessageDialog(null, "Sucessores: "+text, "", 1);
	}
		
	}
	
	

