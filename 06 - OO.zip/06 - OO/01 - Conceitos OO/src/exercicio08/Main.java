package exercicio08;

public class Main {

	public static void main(String[] args) {
		
		System e = new System();
		e.pedirNum();
		e.exibirAnte();
		e.exibirSuc();
		
		
		
	}
	
}
