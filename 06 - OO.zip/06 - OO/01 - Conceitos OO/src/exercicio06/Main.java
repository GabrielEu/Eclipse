package exercicio06;

public class Main {

	public static void main(String[] args) {
		
		Info exibir = new Info();
		exibir.exibirNome();
		exibir.exibirSexo();
		exibir.exibirNotas();
		exibir.mediaECondicao();
		exibir.calculo();
		exibir.exibirEstatisticas();
		exibir.laco();
	}
	
}
