package exercicio06;

import javax.swing.*;

public class Info {

	//Vari�veis
	double nota1, nota2, nota3, nota4, media, pctgHomens, pctgMulheres;
	double pctg10, pctg9, pctg8, pctg7, pctg5, pctgReprov;
	int cont10, cont9, cont8, cont7, cont5, contReprov;
	int homens = 0, mulheres = 0, total;
	String condicao, text = "";
	String informarNome;
	boolean validar;
	int contar = 0;
	
	//Pedir nome
	public void exibirNome() {
	
		if(contar == 0) {
			informarNome = JOptionPane.showInputDialog(null, "Informe seu nome ou SAIR para finalizar", "", 3);
			contar++;
		}
	}
	
	//Pedir sexo
	public String exibirSexo() {
		
		String informarSexo = JOptionPane.showInputDialog(null, "Informe seu sexo", "", 3);
		
		if(informarSexo.equals("masculino")) {
			homens++;
		} else if(informarSexo.equals("feminino")) {
			mulheres++;
		}
		
		return informarSexo;
	}
	
	//Notas
	public void exibirNotas() {
		
		nota1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua 1� nota", "", 3));
		nota2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua 2� nota", "", 3));
		nota3 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua 3� nota", "", 3));
		nota4 = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua 4� nota", "", 3));
		
	}
	
	//Calcular media e exibir condi��o
	public void mediaECondicao() {
		
		media = (nota1+nota2+nota3+nota4) / 4;
		
		if(media == 10) {
			condicao = "Parab�ns!";
			cont10++;
		} else if((media >= 9) && (media <= 9.9)){
			condicao = "�timo";
			cont9++;
		}else if((media >= 8) && (media <= 8.9)){
			condicao = "Bom";
			cont8++;
		}else if((media >= 7) && (media <= 7.9)){
			condicao = "Satisfat�rio";
			cont7++;
		}else if((media >= 5) && (media <= 5.9)){
			condicao = "Recupera��o";
			cont5++;
		} else {
			condicao = "Reprovado!";
			contReprov++;
		}
		
		JOptionPane.showMessageDialog(null, condicao+" Voc� foi com m�dia "+media);
		
	}
	
	//La�o
	public void laco(){
		
		while(validar == true) {
			
			exibirNome();
			exibirSexo();
			exibirNotas();
			mediaECondicao();
			calculo();
			exibirEstatisticas();
		}
	}
	
	//Calculo porcentagem
	public void calculo() {
		total = homens + mulheres;
		pctgHomens = (homens * 100) / total;
		pctgMulheres = (mulheres * 100) / total;
		
		total = cont10 + cont9 + cont8 + cont7 + cont5 + contReprov;
		pctg10 = (cont10 * 100) / total;
		pctg9 = (cont9 * 100) / total;
		pctg8 = (cont8 * 100) / total;
		pctg7 = (cont7 * 100) / total;
		pctg5 = (cont5 * 100) / total;
		pctgReprov = (contReprov * 100) / total;
		
	}
	
	
	
	//Estat�sticas
	public void exibirEstatisticas() {
		
		informarNome = JOptionPane.showInputDialog(null, "Informe seu nome ou SAIR para finalizar", "", 3);
		
		if((informarNome.equals("sair")) || (informarNome.equals("SAIR"))) {
			
			JOptionPane.showMessageDialog(null, "S�o "+homens+" homens("+pctgHomens+"%) e "+mulheres+" mulheres("+pctgMulheres+"%)");
			text += "Notas 10: "+cont10+" | "+pctg10+"%\n";
			text += "Notas 9: "+cont9+" | "+pctg9+"%\n";
			text += "Notas 8: "+cont8+" | "+pctg8+"%\n";
			text += "Notas 7: "+cont7+" | "+pctg7+"%\n";
			text += "Notas 5: "+cont5+" | "+pctg5+"%\n";
			text += "Reprovados: "+contReprov+" | "+pctgReprov+"%";
			
			JOptionPane.showMessageDialog(null, text);
			
			validar = false;
			
		}else {
			validar = true;
		}
	}
	
	
}
