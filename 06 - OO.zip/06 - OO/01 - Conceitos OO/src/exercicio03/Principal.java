package exercicio03;

public class Principal {
	
	public static void main(String[] args) {

		System view = new System();
		view.atribuirVariaveis();
		view.cardapio();
		view.compra();
		view.totalAPagar();
		
		
	
	}

}
