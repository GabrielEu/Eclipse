package exercicio03;

import javax.swing.JOptionPane;

public class System {

	//Vari�veis
	double[] precos = new double[7];
	int[] codigo = new int[7];
	int pedido, quantidade;
	int pagamento, troco;
	double  totalCompra = 0;
	String[] produtos = new String[7];
	String text = "Produto         |         Pre�o         |         C�digo\n";
	boolean validar = false;
	
	public void atribuirVariaveis() {
		produtos[0] = "Hamb�rguer + suco de laranja";
		produtos[1] = "Sandu�che natural + Suco de Uva ";
		produtos[2] = "Prato do dia ";
		produtos[3] = "Pizza";
		produtos[4] = "Lasanha";
		produtos[5] = "P�o de queijo";
		produtos[6] = "Bolo";
		
		precos[0] = 5;
		precos[1] = 4.50;
		precos[2] = 8;
		precos[3] = 12;
		precos[4] = 16.50;
		precos[5] = 1;
		precos[6] = 2.50;
		
		for(int i = 0; i < 7; i++) {
			
			codigo[i] = i+1;
			
		}	
	}
	
	//Criar card�pio
	public void cardapio(){
		
		for(int i = 0; i < 7; i++) {
			
			text += produtos[i]+"        "+precos[i]+"         "+codigo[i]+"\n";
			
		}
	}
	
	//La�o compra
	public void compra() {
		
		pedido = Integer.parseInt(JOptionPane.showInputDialog(null, text+"\n\nInforme o c�digo do produto que deseja comprar \nOu 0 para finalizar", "", 3));
		quantidade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade que deseja pedir", "", 3));
		
		do {
			if(pedido == 1) {
				totalCompra += 5 * quantidade;
			} else if(pedido == 2) {
				totalCompra += 4.50 * quantidade;
			}else if(pedido == 3) {
				totalCompra += 8 * quantidade;
			}else if(pedido == 4) {
				totalCompra += 12 * quantidade;
			}else if(pedido == 5) {
				totalCompra += 16.50 * quantidade;
			}else if(pedido == 6) {
				totalCompra += 1 * quantidade;
			}else if(pedido == 7) {
				totalCompra += 2.50 * quantidade;
			} else {
				JOptionPane.showMessageDialog(null, "Produto n�o encontrado", "*****  ERROR  *****", 3);
			}
			
			pedido = Integer.parseInt(JOptionPane.showInputDialog(null, text+"\n\nInforme o c�digo do produto que deseja comprar \nOu 0 para finalizar", "", 3));
			quantidade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a quantidade que deseja pedir", "", 3));
			
		}while(pedido != 0);
		
	}
	
	//Total da compra
	public void totalAPagar() {
		
		do {
		pagamento = Integer.parseInt(JOptionPane.showInputDialog(null, "O total da sua compra foi de "+totalCompra+"R$\nInforme a quantida que ir� pagar", "*****  PAGAMENTO  *****", 3));
		
		if(pagamento < totalCompra) {
			
			JOptionPane.showMessageDialog(null, "Voc� inseriu um valor menor que sua compra, tente novamente", "*****  ERROR  *****", 3);
			validar = false;
		
		} else {
			JOptionPane.showMessageDialog(null, "Obrigado pela prefer�ncia! Volte sempre :)", "*****  PAGAMENTO EFETUADO  *****", 1);
			
			troco = (int) ((double) pagamento - totalCompra);
			
			JOptionPane.showMessageDialog(null, "Seu troco � de "+troco+"R$");
			
			validar = true;
		}
		
		}while(validar == false);
	
	
	}
	
}
