package exercicio01;

public class Principal {

	public static void main(String[] args) {
		
		Pessoa p1 = new Pessoa();
		p1.nome();
		p1.idade();
		p1.sexo();
		p1.apresentarCargos();
		
		p1.laco();
		
		p1.apresentarInfo();
		
	}
}