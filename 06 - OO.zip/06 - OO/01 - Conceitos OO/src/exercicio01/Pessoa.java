package exercicio01;

import javax.swing.JOptionPane;

public class Pessoa {
		
		//Vari�veis
		String informarNome, informarSexo;
		int informarIdade, masculino = 0, feminino = 0;
		int maior = 0, menor = 0;
		int gerente = 0, atendente = 0, acougueiro = 0, secretaria = 0, almoxarife = 0, padeiro = 0, estagiario = 0;
		Object[] cargos = {"Gerente", "Atendente", "A�ougueiro", "Secret�ria", "Almoxarife", "Padeiro", "Estagi�rio"};
		int continuar = 0;
		
		//Atribuir nome
		public String nome() {
					
			informarNome = JOptionPane.showInputDialog(null, "Informe seu nome", "", 3);
		
			return informarNome;
		}
		
		
		//Atribuir idade
		public int idade() {
			
			informarIdade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe sua idade", "", 1));
			
			if(informarIdade < 18) {
				menor++;
			} else {
				maior++;
			}
			
			
			return informarIdade;
		
		}
		
		//Atribuir sexo
		public String sexo() {
			
			informarSexo = JOptionPane.showInputDialog(null, "Informe seu sexo", "", 3);
			
			if((informarSexo.equals("Masculino")) || (informarSexo.equals("masculino"))) {
				masculino++;
			} else {
				feminino++;
			}
			
			return informarSexo;
			
		}
		
		//Atribuir cargo
		public String apresentarCargos() {
			
			Object escolha = JOptionPane.showInputDialog(null, "Informe seu cargo", "", JOptionPane.PLAIN_MESSAGE, null, cargos, "");
			
			if(apresentarCargos().equals("Gerente")) {
				gerente++;
			} else if(apresentarCargos().equals("Atendente")) {
				atendente++;
			} else if(apresentarCargos().equals("A�ougueiro")) {
				acougueiro++;
			} else if(apresentarCargos().equals("Secret�ria")) {
				secretaria++;
			} else if(apresentarCargos().equals("Almoxarife")) {
				almoxarife++;
			} else if(apresentarCargos().equals("Padeiro")) {
				padeiro++;
			} else {
				estagiario++;
			}
			
			return (String) escolha;
			
		}
		
		
		//La�o
		public void laco() {
			
			continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar?", "", 1);
			
			while(continuar == 0){
				
				nome();
				idade();
				sexo();
				apresentarCargos();
				
			}
			
		}
		
		//Escrever informa��es
		public void apresentarInfo() {
			
			String msg ="S�o "+masculino+"Homens e "+feminino+" mulheres\n\n";
					msg += "S�o "+menor+" menores de idade e \n"+maior+" maiores de idade\n\n";
					msg += "Gerentes: "+gerente+"\nAtendente: "+atendente+"\nA�ougueiro: "+acougueiro+"\nSecret�ria: "+secretaria+"\nAlmoxarife: "+almoxarife+
							"\nPadeiro: "+padeiro+"\nEstagi�rio: "+estagiario;
					
					
			JOptionPane.showMessageDialog(null, msg);
		}

		
}	
	

