package exercicio05;

public class Main {

	public static void main(String[] args) {
		
		System exibir = new System();
		exibir.exibirProduto();
		exibir.calcDesconto();
		exibir.exibirTabela();
	}
	
	
}
