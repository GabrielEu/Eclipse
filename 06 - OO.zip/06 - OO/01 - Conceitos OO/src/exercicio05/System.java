package exercicio05;

import javax.swing.*;

public class System {

	//Vari�veis
	String produto, text = "";
	double valor, pctgDesconto, total;
	double[] desconto = new double[10];
	
	//Pedir produto
	public void exibirProduto(){
		
		produto = JOptionPane.showInputDialog(null, "Informe o produto adquirido", "", 3);
		valor = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor do produto", "", 3));
	}
	
	//Porcentagem de desconto
	public void calcDesconto() {
		
		for(int i = 0; i < 10; i++) {
			
			if(i == 0) {
				pctgDesconto = 0.95;
			} else if(i == 1) {
				pctgDesconto = 0.90;
			} else if(i == 2) {
				pctgDesconto = 0.85;
			} else if(i == 3) {
				pctgDesconto = 0.80;
			} else if(i == 4) {
				pctgDesconto = 0.75;
			} else if(i == 5) {
				pctgDesconto = 0.70;
			} else if(i == 6) {
				pctgDesconto = 0.65;
			} else if(i == 7) {
				pctgDesconto = 0.60;
			} else if(i == 8) {
				pctgDesconto = 0.55;
			} else if(i == 9) {
				pctgDesconto = 0.50;
			}
			
			desconto[i] = valor * pctgDesconto;
		
		}
		
	}
	
	//Escrever tabela
	public void exibirTabela() {
		
		for(int i = 0; i < 10; i++) {
			
			total = desconto[i] * (i+1);
			
			text += (i+1)+" X R$"+desconto[i]+" = R$"+String.format("%.2f",total)+"\n";
			
		}
		
		JOptionPane.showMessageDialog(null, text);
	}
	
		
	}

