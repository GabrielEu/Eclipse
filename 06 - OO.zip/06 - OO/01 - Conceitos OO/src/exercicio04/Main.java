package exercicio04;

public class Main {

	public static void main(String[] args) {
		
		Filme exe = new Filme();
		exe.idade();
		exe.avaliar();
		exe.laco();
		exe.pctgVotos();
		exe.exibirPorcentagens();
		
		
	}
	
}
