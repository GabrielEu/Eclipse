package exercicio04;

import javax.swing.JOptionPane;

public class Filme {

	//Vari�veis
	Object[] notas  = {"Excelente", "�timo", "Bom", "Regular", "Ruim"};
	int idade, totalVotos, continuar, crianca = 0, adole = 0, adulto = 0;
	int contEx = 0, contOt = 0, contBom = 0, contReg = 0, contRu = 0;
	double pctgEx, pctgOt, pctgBom, pctgReg, pctgRu, pctgCrianca, pctgAdol, pctgAdulto;
	boolean validar = false;
	
	//Informar idade
	public void idade() {
		do {
			idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe sua idade", "", 3));
			
			if((idade < 0) && (idade > 100)){
				
				JOptionPane.showMessageDialog(null, "Idade inv�lida", "*****  ERROR  *****", 3);
				validar = false;
				
			} else {
				
				if(idade <= 9) {
					crianca++;
				} else if(idade <= 17) {
					adole++;
				} else {
					adulto++;
				}
				
				validar = true;
			}
		
		}while(validar == false);
	}
	
	
	
	//Avaliar
	public void avaliar() {
			
		Object escolha = JOptionPane.showInputDialog(null, "Avalie o filme", "", JOptionPane.PLAIN_MESSAGE, null, notas, "");
		
		if(escolha.equals("Excelente")) {
			contEx++;
		} else if(escolha.equals("�timo")) {
			contOt++;
		} else if(escolha.equals("Bom")) {
			contBom++;
		} else if(escolha.equals("Regular")) {
			contReg++;
		} else if(escolha.equals("Ruim")) {
			contRu++;
		}
		
		totalVotos++;
	}
	
	//La�o
	public void laco() {
		
		continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar?", "", 1);
		
		do {
			idade();
			avaliar();
			continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar?", "", 1);
		}while(continuar == 0);
		
		
	}
	
	//Porcentagem de votos
	public void pctgVotos() {
		
		pctgEx = (contEx * 100) / totalVotos;
		pctgOt = (contOt * 100) / totalVotos;
		pctgBom = (contBom * 100) / totalVotos;
		pctgReg = (contReg * 100) / totalVotos;
		pctgRu = (contRu * 100) / totalVotos;
		
		pctgCrianca = (crianca * 100) / totalVotos;
		pctgAdol = (adole * 100) / totalVotos;
		pctgAdulto = (adulto * 100) / totalVotos;
	}
	
	//Porcentagem de idades
	public void exibirPorcentagens() {
		
		JOptionPane.showMessageDialog(null, "Porcentagem de votos\n\nExcelentes: "+pctgEx+"%\n�timos: "+pctgOt+"%\nBons: "+pctgBom+"%\nRegulares: "+pctgReg+"%\nRuins: "+pctgRu+"%");
		JOptionPane.showMessageDialog(null, "A porcentagem de crian�as � de "+pctgCrianca+"%, a de adolescentes � de "+pctgAdol+"% e a de adultos � de "+pctgAdulto+"%");
	}
	
}
