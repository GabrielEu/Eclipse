package exercicio09;

import javax.swing.JOptionPane;

public class System {

	//Vari�veis
	int[] ano = new int[100];
	int continuar = 0, contarAnos = 0;
	String anoBi = "", anoNaoBi = "";
	
	//Informar ano
	public void pedirAno() {
		
		for(int i = 0; continuar == 0; i++) {
			ano[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um ano", "", 1));
			contarAnos++;
			
			continuar = JOptionPane.showConfirmDialog(null, "Deseja continuar?");
		}
	}
	
	//Verificar bissexto
	public void verificarBissexto() {
		
		for(int i = 0; contarAnos != 0; contarAnos--) {
			
			if((ano[i] % 4) == 0) {
				anoBi += ano[i]+" ser� bissexto\n";
			} else {
				anoNaoBi += ano[i]+" n�o ser� bissexto\n";
			}
			
		i++;
		}
	}
	
	//Exibir anos bissextos
	public void exibirAnos() {
		
		JOptionPane.showMessageDialog(null, anoBi);
		JOptionPane.showMessageDialog(null, anoNaoBi);
		
	}
	
}
