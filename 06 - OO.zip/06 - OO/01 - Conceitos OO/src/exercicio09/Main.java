package exercicio09;

public class Main {

	public static void main(String[] args) {
		
		System e = new System();
		e.pedirAno();
		e.verificarBissexto();
		e.exibirAnos();
		
	}
	
}
