package exemplo01;

import javax.swing.JOptionPane;

public class Pessoa {
	
	//Construtor #01
	public Pessoa() {
		JOptionPane.showMessageDialog(null, "Boa tarde");
	}
	
	//Construtor #02
	public Pessoa(String nome) {
		JOptionPane.showMessageDialog(null, "Boa tarde "+nome);
	}
	
	//Construtor #03
	public Pessoa(String nome, int hora) {
		
		if(hora < 12) {
			JOptionPane.showMessageDialog(null,  "Bom dia "+nome);
		} else if(hora < 18) {
			JOptionPane.showMessageDialog(null,  "Boa tarde "+nome);	
		} else {
			JOptionPane.showMessageDialog(null,  "Boa noite "+nome);	
		}
		
	}
	
}
