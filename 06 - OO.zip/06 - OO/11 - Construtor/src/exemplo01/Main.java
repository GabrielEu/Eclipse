package exemplo01;

import javax.swing.JOptionPane;

public class Main {


	public static void main(String[] args) {
		
	
	Pessoa p1 = new Pessoa();
	Pessoa p2 = new Pessoa("Ralf");
	Pessoa p3 = new Pessoa("Ralf", 1);
	
	
	}	
}
