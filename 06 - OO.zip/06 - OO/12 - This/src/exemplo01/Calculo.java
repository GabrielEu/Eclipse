package exemplo01;

import javax.swing.JOptionPane;

public class Calculo {

	//Atributo da classe
	public double resultado = 10;
	
	//M�todo para exibir um resultado
	public void resultado() {
			
			//Vari�vel local
			double resultado = 5;
			
			JOptionPane.showMessageDialog(null, this.resultado);
	}
	
	
	
}
