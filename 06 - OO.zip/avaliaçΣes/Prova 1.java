//Importar classe
import javax.swing.*;

//Iniciar
public class Prova{

    public static void main(String[] args){
    
    //Variáveis
    String nome, cargo, sexo;
    int idade, faltas, filhos, VTransporte, clube, laco,  loop = 0;
    double HExtra50, HExtra100, HExtraDiaria, HExtraTotal, salario, salarioTotal, salarioTotal2, descontoVT, INSS, descontoINSS;
    Object[] cargos = {"Desenvolvedor Java Júnior", "Desenvolvedor Java Pleno", "Desenvolvedor Jana Sênior", "Administrador de Banco de Dados ", "Analista Júnior", "Analista Pleno", 
                       "Analista Sênior", "Arquiteto de Software", "Gerente de Projetos"};


//Laço
laco = 0;
while(laco != 1){

    //Contagem
    loop++;
        
    //Atribuir nome
    nome = JOptionPane.showInputDialog(null, "Informe seu nome", "", 1);
        
    //Combo
    Object escolhaCargo = JOptionPane.showInputDialog(null, "Informe seu cargo", "", JOptionPane.PLAIN_MESSAGE, null, cargos, "");

    //Atribuir horas extras
    HExtra50 = Double.parseDouble(JOptionPane.showInputDialog(null, "Quantas horas extras (50%) foram feitas?", "", 1));
    HExtra100 = Double.parseDouble(JOptionPane.showInputDialog(null, "Quantas horas extras (100%) foram feitas?", "", 1));
    VTransporte = JOptionPane.showConfirmDialog(null, "Você usa vale transporte?", "", 1);

    //Atribuir informações

        //Contagem homens e mulheres
        int homens = 0;
        int mulheres = 0;

        sexo = JOptionPane.showInputDialog(null, "Informe seu sexo", "", 1);
            if(sexo.equals("masculino")){
                homens++;
            } else if("feminino"){
                mulheres++;
            } else{

            }

        //Contagem de idade
        int idade1, idade2, idade3, idade4;
        idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe sua idade", "", 1));
            if((idade >= 18) && (idade <=26)){
                idade1 = 1;
            } else if((idade >= 27) && (idade <= 40)){
                idade2 = 1;
            } else if((idade >= 41) && (idade <= 50)){
                idade3 = 1;
            } else if{
                idade4 = 1;
            }

    faltas = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe faltas mensais", "", 1));
    filhos = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe quantos filhos você tem", "", 1));
    clube = JOptionPane.showConfirmDialog(null, "É associado ao Clube Fidelidade?", "", 1);

    //Atribuir salário
    if(escolhaCargo == ("Desenvolvedor Java Júnior")){
        salario = 1450;
    } else if(escolhaCargo == ("Desenvolvedor Java Pleno")){
        salario = 2220;
    } else if(escolhaCargo == ("Desenvolvedor Jana Sênior")){
        salario = 2220;
    } else if(escolhaCargo == ("Administrador de Banco de Dados")){
        salario = 2220;
    } else if(escolhaCargo == ("Analista Júnior")){
        salario = 2220;
    } else if(escolhaCargo == ("Analista Pleno")){
        salario = 2220;
    } else if(escolhaCargo == ("Analista Sênior")){
        salario = 2220;
    } else if(escolhaCargo == ("Arquiteto de Software")){
        salario = 2220;
    } else{
        salario = 2220;
    }

    //Beneficios

        //Calc. horas extras
        HExtraDiaria = salario / 160;
        HExtraTotal = HExtraDiaria * HExtra50;
        HExtraTotal += HExtraDiaria * HExtra100;

        //Bonificação
        if(faltas == 0){
            salario += 200;
        } else{
        
        }

        //Benefício filhos
        salario += 50 * filhos;


    //Descontos

        //Atribuir desconto VT
        if(VTransporte == 0){
            descontoVT = salario * 0.06;
        } else{
        
        }

        //Clube
        if(clube == 1){
            salario += -100;
        } else{

        }

        //Calc. INSS
        salarioTotal = salario + HExtraTotal;
    
        if(salarioTotal <= 2.000){
            INSS = 0.05;
        } else if(salarioTotal >= 3.500){
            INSS = 0.07;
        } else if(salarioTotal >= 5.600){
            INSS = 0.08;
        } else{
            INSS = 0.1;
        }

        descontoINSS = salario * INSS;
        salarioTotal += -descontoINSS;
        //Exibir salário
        JOptionPane.showMessageDialog(null, "Seu salário líquido é de "+salarioTotal+",00 R$");

        //Fim do laço
        laco = JOptionPane.showConfirmDialog(null, "Deseja continuar a cadastrar mais funcionários?", "", 1);

        }

        //Valores da segunda parte
        int PCTGEMhomens, PCTGEMtotalmulheres, TOTAL;

        //Calcular porcentagem de sexos
        TOTAL = homens + mulheres;
        PCTGEMhomens = (homens * 100) /TOTAL;
        PCTGEMmulheres = (mulheres * 100) /TOTAL;

        
        JOptionPane.showMessageDialog(null, "Foram cadastrados "+loop+" funcionários", "", 1);
        JOptionPane.showMessageDialog(null, PCTGEhomens+"% dos cadastrados eram homens\n"+PCTGEmulheres+" dos cadastrados eram mulheres", "", 1);

        String texto = (idade1+" funcionários com 18 a 26 anos foram cadastrados\n");
                texto += (idade2+" funcionários com  27 a 40 anos foram cadastrados\n");
                texto += (idade3+" funcionários com 41 a 50 anos foram cadastrados\n");
        JOptionPane.showMessageDialog(null, 


    }

}
